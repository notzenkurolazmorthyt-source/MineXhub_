CREATE EXTENSION IF NOT EXISTS "pg_cron";
CREATE EXTENSION IF NOT EXISTS "pg_graphql";
CREATE EXTENSION IF NOT EXISTS "pg_net";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "plpgsql";
CREATE EXTENSION IF NOT EXISTS "supabase_vault";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
--
-- PostgreSQL database dump
--


-- Dumped from database version 17.6
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--



--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.app_role AS ENUM (
    'admin',
    'moderator',
    'user'
);


--
-- Name: loader_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.loader_type AS ENUM (
    'fabric',
    'forge',
    'quilt',
    'neoforge',
    'optifine',
    'iris',
    'vanilla',
    'paper',
    'spigot',
    'velocity',
    'bukkit',
    'purpur'
);


--
-- Name: mod_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.mod_status AS ENUM (
    'approved',
    'pending',
    'rejected',
    'draft'
);


--
-- Name: mod_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.mod_type AS ENUM (
    'mod',
    'resourcepack',
    'shader',
    'plugin',
    'datapack',
    'modpack'
);


--
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  INSERT INTO public.profiles (id, username, display_name)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', SPLIT_PART(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'display_name', SPLIT_PART(NEW.email, '@', 1))
  );
  RETURN NEW;
END;
$$;


--
-- Name: has_role(uuid, public.app_role); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.has_role(_user_id uuid, _role public.app_role) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO ''
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    icon text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: download_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.download_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    mod_id uuid NOT NULL,
    version_id uuid NOT NULL,
    ip_address text,
    user_agent text,
    downloaded_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: minecraft_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.minecraft_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    version text NOT NULL,
    release_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: mod_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mod_categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    mod_id uuid NOT NULL,
    category_id uuid NOT NULL
);


--
-- Name: mod_dependencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mod_dependencies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    version_id uuid NOT NULL,
    dependency_mod_id uuid,
    dependency_type text NOT NULL,
    version_requirement text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: mod_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mod_images (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    mod_id uuid NOT NULL,
    url text NOT NULL,
    title text,
    description text,
    ordering integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: mod_reactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mod_reactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    mod_id uuid NOT NULL,
    user_id uuid NOT NULL,
    reaction_type text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mod_reactions_reaction_type_check CHECK ((reaction_type = ANY (ARRAY['like'::text, 'dislike'::text])))
);


--
-- Name: mod_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mod_tags (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    mod_id uuid NOT NULL,
    tag_id uuid NOT NULL
);


--
-- Name: mod_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mod_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    mod_id uuid NOT NULL,
    version_number text NOT NULL,
    name text,
    changelog text,
    downloads integer DEFAULT 0 NOT NULL,
    file_url text NOT NULL,
    file_name text NOT NULL,
    file_size bigint NOT NULL,
    file_hash text,
    modrinth_version_id text,
    published_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    is_external_link boolean DEFAULT false NOT NULL,
    external_url text
);


--
-- Name: mods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    summary text NOT NULL,
    description text NOT NULL,
    author_id uuid,
    mod_type public.mod_type DEFAULT 'mod'::public.mod_type NOT NULL,
    status public.mod_status DEFAULT 'pending'::public.mod_status NOT NULL,
    modrinth_id text,
    curseforge_id text,
    icon_url text,
    banner_url text,
    downloads integer DEFAULT 0 NOT NULL,
    followers integer DEFAULT 0 NOT NULL,
    featured boolean DEFAULT false NOT NULL,
    source_url text,
    issues_url text,
    wiki_url text,
    discord_url text,
    last_synced_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    edition text DEFAULT 'java'::text,
    likes integer DEFAULT 0 NOT NULL,
    dislikes integer DEFAULT 0 NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    CONSTRAINT mods_edition_check CHECK ((edition = ANY (ARRAY['java'::text, 'bedrock'::text, 'both'::text])))
);


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL,
    username text NOT NULL,
    display_name text,
    avatar_url text,
    bio text,
    website text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_favorites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_favorites (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    mod_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    role public.app_role NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: version_game_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.version_game_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    version_id uuid NOT NULL,
    minecraft_version_id uuid NOT NULL
);


--
-- Name: version_loaders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.version_loaders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    version_id uuid NOT NULL,
    loader public.loader_type NOT NULL
);


--
-- Name: categories categories_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_name_key UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: categories categories_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_slug_key UNIQUE (slug);


--
-- Name: download_history download_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.download_history
    ADD CONSTRAINT download_history_pkey PRIMARY KEY (id);


--
-- Name: minecraft_versions minecraft_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.minecraft_versions
    ADD CONSTRAINT minecraft_versions_pkey PRIMARY KEY (id);


--
-- Name: minecraft_versions minecraft_versions_version_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.minecraft_versions
    ADD CONSTRAINT minecraft_versions_version_key UNIQUE (version);


--
-- Name: mod_categories mod_categories_mod_id_category_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_categories
    ADD CONSTRAINT mod_categories_mod_id_category_id_key UNIQUE (mod_id, category_id);


--
-- Name: mod_categories mod_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_categories
    ADD CONSTRAINT mod_categories_pkey PRIMARY KEY (id);


--
-- Name: mod_dependencies mod_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_dependencies
    ADD CONSTRAINT mod_dependencies_pkey PRIMARY KEY (id);


--
-- Name: mod_images mod_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_images
    ADD CONSTRAINT mod_images_pkey PRIMARY KEY (id);


--
-- Name: mod_reactions mod_reactions_mod_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_reactions
    ADD CONSTRAINT mod_reactions_mod_id_user_id_key UNIQUE (mod_id, user_id);


--
-- Name: mod_reactions mod_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_reactions
    ADD CONSTRAINT mod_reactions_pkey PRIMARY KEY (id);


--
-- Name: mod_tags mod_tags_mod_id_tag_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_tags
    ADD CONSTRAINT mod_tags_mod_id_tag_id_key UNIQUE (mod_id, tag_id);


--
-- Name: mod_tags mod_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_tags
    ADD CONSTRAINT mod_tags_pkey PRIMARY KEY (id);


--
-- Name: mod_versions mod_versions_mod_id_version_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_versions
    ADD CONSTRAINT mod_versions_mod_id_version_number_key UNIQUE (mod_id, version_number);


--
-- Name: mod_versions mod_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_versions
    ADD CONSTRAINT mod_versions_pkey PRIMARY KEY (id);


--
-- Name: mods mods_modrinth_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mods
    ADD CONSTRAINT mods_modrinth_id_key UNIQUE (modrinth_id);


--
-- Name: mods mods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mods
    ADD CONSTRAINT mods_pkey PRIMARY KEY (id);


--
-- Name: mods mods_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mods
    ADD CONSTRAINT mods_slug_key UNIQUE (slug);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_username_key UNIQUE (username);


--
-- Name: tags tags_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_name_key UNIQUE (name);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tags tags_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_slug_key UNIQUE (slug);


--
-- Name: user_favorites user_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_pkey PRIMARY KEY (id);


--
-- Name: user_favorites user_favorites_user_id_mod_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_user_id_mod_id_key UNIQUE (user_id, mod_id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_user_id_role_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_key UNIQUE (user_id, role);


--
-- Name: version_game_versions version_game_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version_game_versions
    ADD CONSTRAINT version_game_versions_pkey PRIMARY KEY (id);


--
-- Name: version_game_versions version_game_versions_version_id_minecraft_version_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version_game_versions
    ADD CONSTRAINT version_game_versions_version_id_minecraft_version_id_key UNIQUE (version_id, minecraft_version_id);


--
-- Name: version_loaders version_loaders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version_loaders
    ADD CONSTRAINT version_loaders_pkey PRIMARY KEY (id);


--
-- Name: version_loaders version_loaders_version_id_loader_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version_loaders
    ADD CONSTRAINT version_loaders_version_id_loader_key UNIQUE (version_id, loader);


--
-- Name: idx_download_history_mod; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_download_history_mod ON public.download_history USING btree (mod_id);


--
-- Name: idx_download_history_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_download_history_user ON public.download_history USING btree (user_id);


--
-- Name: idx_mod_versions_mod; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mod_versions_mod ON public.mod_versions USING btree (mod_id);


--
-- Name: idx_mods_author; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mods_author ON public.mods USING btree (author_id);


--
-- Name: idx_mods_downloads; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mods_downloads ON public.mods USING btree (downloads DESC);


--
-- Name: idx_mods_modrinth; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mods_modrinth ON public.mods USING btree (modrinth_id);


--
-- Name: idx_mods_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mods_slug ON public.mods USING btree (slug);


--
-- Name: idx_mods_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mods_status ON public.mods USING btree (status);


--
-- Name: idx_mods_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mods_type ON public.mods USING btree (mod_type);


--
-- Name: idx_user_favorites_mod; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_favorites_mod ON public.user_favorites USING btree (mod_id);


--
-- Name: idx_user_favorites_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_favorites_user ON public.user_favorites USING btree (user_id);


--
-- Name: mods update_mods_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_mods_updated_at BEFORE UPDATE ON public.mods FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: profiles update_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: download_history download_history_mod_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.download_history
    ADD CONSTRAINT download_history_mod_id_fkey FOREIGN KEY (mod_id) REFERENCES public.mods(id) ON DELETE CASCADE;


--
-- Name: download_history download_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.download_history
    ADD CONSTRAINT download_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: download_history download_history_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.download_history
    ADD CONSTRAINT download_history_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.mod_versions(id) ON DELETE CASCADE;


--
-- Name: mod_categories mod_categories_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_categories
    ADD CONSTRAINT mod_categories_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: mod_categories mod_categories_mod_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_categories
    ADD CONSTRAINT mod_categories_mod_id_fkey FOREIGN KEY (mod_id) REFERENCES public.mods(id) ON DELETE CASCADE;


--
-- Name: mod_dependencies mod_dependencies_dependency_mod_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_dependencies
    ADD CONSTRAINT mod_dependencies_dependency_mod_id_fkey FOREIGN KEY (dependency_mod_id) REFERENCES public.mods(id) ON DELETE CASCADE;


--
-- Name: mod_dependencies mod_dependencies_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_dependencies
    ADD CONSTRAINT mod_dependencies_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.mod_versions(id) ON DELETE CASCADE;


--
-- Name: mod_images mod_images_mod_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_images
    ADD CONSTRAINT mod_images_mod_id_fkey FOREIGN KEY (mod_id) REFERENCES public.mods(id) ON DELETE CASCADE;


--
-- Name: mod_reactions mod_reactions_mod_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_reactions
    ADD CONSTRAINT mod_reactions_mod_id_fkey FOREIGN KEY (mod_id) REFERENCES public.mods(id) ON DELETE CASCADE;


--
-- Name: mod_reactions mod_reactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_reactions
    ADD CONSTRAINT mod_reactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mod_tags mod_tags_mod_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_tags
    ADD CONSTRAINT mod_tags_mod_id_fkey FOREIGN KEY (mod_id) REFERENCES public.mods(id) ON DELETE CASCADE;


--
-- Name: mod_tags mod_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_tags
    ADD CONSTRAINT mod_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: mod_versions mod_versions_mod_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mod_versions
    ADD CONSTRAINT mod_versions_mod_id_fkey FOREIGN KEY (mod_id) REFERENCES public.mods(id) ON DELETE CASCADE;


--
-- Name: mods mods_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mods
    ADD CONSTRAINT mods_author_id_fkey FOREIGN KEY (author_id) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: user_favorites user_favorites_mod_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_mod_id_fkey FOREIGN KEY (mod_id) REFERENCES public.mods(id) ON DELETE CASCADE;


--
-- Name: user_favorites user_favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: version_game_versions version_game_versions_minecraft_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version_game_versions
    ADD CONSTRAINT version_game_versions_minecraft_version_id_fkey FOREIGN KEY (minecraft_version_id) REFERENCES public.minecraft_versions(id) ON DELETE CASCADE;


--
-- Name: version_game_versions version_game_versions_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version_game_versions
    ADD CONSTRAINT version_game_versions_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.mod_versions(id) ON DELETE CASCADE;


--
-- Name: version_loaders version_loaders_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version_loaders
    ADD CONSTRAINT version_loaders_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.mod_versions(id) ON DELETE CASCADE;


--
-- Name: download_history Anyone can insert download history; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can insert download history" ON public.download_history FOR INSERT WITH CHECK (true);


--
-- Name: mod_reactions Anyone can view reactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can view reactions" ON public.mod_reactions FOR SELECT USING (true);


--
-- Name: mods Authenticated users can create mods; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Authenticated users can create mods" ON public.mods FOR INSERT WITH CHECK ((auth.uid() = author_id));


--
-- Name: mod_reactions Authenticated users can create reactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Authenticated users can create reactions" ON public.mod_reactions FOR INSERT TO authenticated WITH CHECK ((auth.uid() = user_id));


--
-- Name: mods Authors and admins can update mods; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Authors and admins can update mods" ON public.mods FOR UPDATE USING (((auth.uid() = author_id) OR public.has_role(auth.uid(), 'admin'::public.app_role)));


--
-- Name: mod_categories Authors can insert mod categories; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Authors can insert mod categories" ON public.mod_categories FOR INSERT TO authenticated WITH CHECK ((EXISTS ( SELECT 1
   FROM public.mods
  WHERE ((mods.id = mod_categories.mod_id) AND (mods.author_id = auth.uid())))));


--
-- Name: mod_images Authors can insert mod images; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Authors can insert mod images" ON public.mod_images FOR INSERT TO authenticated WITH CHECK ((EXISTS ( SELECT 1
   FROM public.mods
  WHERE ((mods.id = mod_images.mod_id) AND (mods.author_id = auth.uid())))));


--
-- Name: mod_tags Authors can insert mod tags; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Authors can insert mod tags" ON public.mod_tags FOR INSERT TO authenticated WITH CHECK ((EXISTS ( SELECT 1
   FROM public.mods
  WHERE ((mods.id = mod_tags.mod_id) AND (mods.author_id = auth.uid())))));


--
-- Name: mod_versions Authors can insert mod versions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Authors can insert mod versions" ON public.mod_versions FOR INSERT TO authenticated WITH CHECK ((EXISTS ( SELECT 1
   FROM public.mods
  WHERE ((mods.id = mod_versions.mod_id) AND (mods.author_id = auth.uid())))));


--
-- Name: version_game_versions Authors can insert version game versions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Authors can insert version game versions" ON public.version_game_versions FOR INSERT TO authenticated WITH CHECK ((EXISTS ( SELECT 1
   FROM (public.mod_versions mv
     JOIN public.mods m ON ((m.id = mv.mod_id)))
  WHERE ((mv.id = version_game_versions.version_id) AND (m.author_id = auth.uid())))));


--
-- Name: version_loaders Authors can insert version loaders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Authors can insert version loaders" ON public.version_loaders FOR INSERT TO authenticated WITH CHECK ((EXISTS ( SELECT 1
   FROM (public.mod_versions mv
     JOIN public.mods m ON ((m.id = mv.mod_id)))
  WHERE ((mv.id = version_loaders.version_id) AND (m.author_id = auth.uid())))));


--
-- Name: categories Categories are viewable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Categories are viewable by everyone" ON public.categories FOR SELECT USING (true);


--
-- Name: minecraft_versions Minecraft versions are viewable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Minecraft versions are viewable by everyone" ON public.minecraft_versions FOR SELECT USING (true);


--
-- Name: mod_categories Mod categories are viewable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Mod categories are viewable by everyone" ON public.mod_categories FOR SELECT USING (true);


--
-- Name: mod_dependencies Mod dependencies are viewable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Mod dependencies are viewable by everyone" ON public.mod_dependencies FOR SELECT USING (true);


--
-- Name: mod_images Mod images are viewable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Mod images are viewable by everyone" ON public.mod_images FOR SELECT USING (true);


--
-- Name: mod_tags Mod tags are viewable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Mod tags are viewable by everyone" ON public.mod_tags FOR SELECT USING (true);


--
-- Name: mod_versions Mod versions are viewable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Mod versions are viewable by everyone" ON public.mod_versions FOR SELECT USING (true);


--
-- Name: mods Mods are viewable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Mods are viewable by everyone" ON public.mods FOR SELECT USING (((status = 'approved'::public.mod_status) OR (author_id = auth.uid()) OR public.has_role(auth.uid(), 'admin'::public.app_role)));


--
-- Name: profiles Public profiles are viewable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Public profiles are viewable by everyone" ON public.profiles FOR SELECT USING (true);


--
-- Name: tags Tags are viewable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Tags are viewable by everyone" ON public.tags FOR SELECT USING (true);


--
-- Name: user_roles User roles are viewable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "User roles are viewable by everyone" ON public.user_roles FOR SELECT USING (true);


--
-- Name: user_favorites Users can create their own favorites; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can create their own favorites" ON public.user_favorites FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: user_favorites Users can delete their own favorites; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can delete their own favorites" ON public.user_favorites FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: mod_reactions Users can delete their own reactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can delete their own reactions" ON public.mod_reactions FOR DELETE TO authenticated USING ((auth.uid() = user_id));


--
-- Name: profiles Users can insert their own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can insert their own profile" ON public.profiles FOR INSERT WITH CHECK ((auth.uid() = id));


--
-- Name: profiles Users can update their own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own profile" ON public.profiles FOR UPDATE USING ((auth.uid() = id));


--
-- Name: mod_reactions Users can update their own reactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own reactions" ON public.mod_reactions FOR UPDATE TO authenticated USING ((auth.uid() = user_id));


--
-- Name: download_history Users can view their own download history; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own download history" ON public.download_history FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: user_favorites Users can view their own favorites; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own favorites" ON public.user_favorites FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: version_game_versions Version game versions are viewable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Version game versions are viewable by everyone" ON public.version_game_versions FOR SELECT USING (true);


--
-- Name: version_loaders Version loaders are viewable by everyone; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Version loaders are viewable by everyone" ON public.version_loaders FOR SELECT USING (true);


--
-- Name: categories; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

--
-- Name: download_history; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.download_history ENABLE ROW LEVEL SECURITY;

--
-- Name: minecraft_versions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.minecraft_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: mod_categories; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mod_categories ENABLE ROW LEVEL SECURITY;

--
-- Name: mod_dependencies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mod_dependencies ENABLE ROW LEVEL SECURITY;

--
-- Name: mod_images; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mod_images ENABLE ROW LEVEL SECURITY;

--
-- Name: mod_reactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mod_reactions ENABLE ROW LEVEL SECURITY;

--
-- Name: mod_tags; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mod_tags ENABLE ROW LEVEL SECURITY;

--
-- Name: mod_versions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mod_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: mods; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mods ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: tags; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tags ENABLE ROW LEVEL SECURITY;

--
-- Name: user_favorites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_favorites ENABLE ROW LEVEL SECURITY;

--
-- Name: user_roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

--
-- Name: version_game_versions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.version_game_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: version_loaders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.version_loaders ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--


