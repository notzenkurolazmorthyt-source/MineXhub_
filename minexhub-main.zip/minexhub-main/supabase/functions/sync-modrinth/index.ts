import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.84.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface ModrinthProject {
  id: string;
  slug: string;
  title: string;
  description: string;
  body: string;
  client_side: string;
  server_side: string;
  project_type: string;
  downloads: number;
  followers: number;
  icon_url?: string;
  banner_url?: string;
  categories: string[];
  versions: string[];
  date_created: string;
  date_modified: string;
  license: { id: string };
  gallery?: Array<{ url: string; featured: boolean; title?: string; description?: string }>;
  issues_url?: string;
  source_url?: string;
  wiki_url?: string;
  discord_url?: string;
}

interface ModrinthVersion {
  id: string;
  project_id: string;
  name: string;
  version_number: string;
  changelog: string;
  date_published: string;
  downloads: number;
  version_type: string;
  files: Array<{
    url: string;
    filename: string;
    primary: boolean;
    size: number;
    hashes: { sha512: string; sha1: string };
  }>;
  game_versions: string[];
  loaders: string[];
  dependencies?: Array<{
    project_id?: string;
    version_id?: string;
    dependency_type?: string;
  }>;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // ============= AUTHENTICATION =============
    const authHeader = req.headers.get('Authorization');
    const cronSecret = Deno.env.get('CRON_SECRET');
    
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const token = authHeader.replace('Bearer ', '');
    
    // Check if it's a CRON secret
    if (token === cronSecret) {
      console.log('✅ Authenticated via CRON_SECRET');
    } else {
      // Verify JWT and check admin role
      const supabaseClient = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_ANON_KEY') ?? '',
        { global: { headers: { Authorization: authHeader } } }
      );
      
      const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
      
      if (authError || !user) {
        return new Response(
          JSON.stringify({ error: 'Unauthorized' }),
          { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      // Check if user has admin role
      const { data: hasAdminRole, error: roleError } = await supabaseClient.rpc('has_role', {
        _user_id: user.id,
        _role: 'admin'
      });
      
      if (roleError || !hasAdminRole) {
        return new Response(
          JSON.stringify({ error: 'Forbidden - Admin access required' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      console.log('✅ Authenticated via admin JWT');
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log('🚀 Comprehensive Modrinth sync initiated');

    // ============= COMPREHENSIVE PROJECT TYPE SYNC =============
    const projectTypes = [
      { type: 'mod', dbType: 'mod' },
      { type: 'shader', dbType: 'shader' },
      { type: 'resourcepack', dbType: 'resourcepack' },
      { type: 'plugin', dbType: 'plugin' },
      { type: 'modpack', dbType: 'modpack' },
      { type: 'datapack', dbType: 'datapack' }
    ];

    let totalSynced = 0;
    let totalErrors = 0;
    const syncResults: any[] = [];

    for (const { type, dbType } of projectTypes) {
      console.log(`\n🔄 Starting sync for ${type}s...`);
      let typeSynced = 0;
      let typeErrors = 0;

      try {
        // Fetch popular projects from Modrinth
        const modrinthResponse = await fetch(
          `https://api.modrinth.com/v2/search?facets=[["project_type:${type}"]]&limit=100&index=downloads`
        );

        if (!modrinthResponse.ok) {
          console.error(`Failed to fetch ${type}s from Modrinth API`);
          continue;
        }

        const data = await modrinthResponse.json();
        console.log(`📦 Fetched ${data.hits?.length || 0} ${type}s from Modrinth`);

        // Process each project
        for (const hit of data.hits || []) {
          try {
            // Fetch full project details
            const projectResponse = await fetch(
              `https://api.modrinth.com/v2/project/${hit.project_id}`
            );

            if (!projectResponse.ok) {
              console.error(`Failed to fetch project ${hit.project_id}`);
              typeErrors++;
              continue;
            }

            const project: ModrinthProject = await projectResponse.json();
            console.log(`\n  📝 Processing ${type}: ${project.title}`);

            // Upsert project data with comprehensive details
            const { data: mod, error: modError } = await supabase
              .from('mods')
              .upsert({
                modrinth_id: project.id,
                slug: project.slug,
                name: project.title,
                summary: project.description,
                description: project.body,
                icon_url: project.icon_url,
                banner_url: project.banner_url || null,
                downloads: project.downloads,
                followers: project.followers,
                mod_type: dbType,
                status: 'approved',
                issues_url: project.issues_url || null,
                source_url: project.source_url || null,
                wiki_url: project.wiki_url || null,
                discord_url: project.discord_url || null,
                last_synced_at: new Date().toISOString()
              }, { onConflict: 'modrinth_id' })
              .select()
              .single();

            if (modError) {
              console.error(`  ❌ Error upserting ${type} ${project.title}:`, modError);
              typeErrors++;
              continue;
            }

            console.log(`  ✅ Synced ${type}: ${project.title} (DB ID: ${mod.id})`);

            // Sync categories
            if (project.categories && project.categories.length > 0) {
              for (const categorySlug of project.categories) {
                const { data: category } = await supabase
                  .from('categories')
                  .select('id')
                  .eq('slug', categorySlug)
                  .single();

                if (category) {
                  await supabase
                    .from('mod_categories')
                    .upsert({
                      mod_id: mod.id,
                      category_id: category.id
                    }, { onConflict: 'mod_id,category_id', ignoreDuplicates: true });
                }
              }
              console.log(`  📂 Synced ${project.categories.length} categories`);
            }

            // Sync gallery images (comprehensive)
            if (project.gallery && project.gallery.length > 0) {
              // Delete old images for this project
              await supabase
                .from('mod_images')
                .delete()
                .eq('mod_id', mod.id);

              // Insert all new images with full details
              for (let i = 0; i < project.gallery.length; i++) {
                const image = project.gallery[i];
                await supabase
                  .from('mod_images')
                  .insert({
                    mod_id: mod.id,
                    url: image.url,
                    title: image.title || `${project.title} Screenshot ${i + 1}`,
                    description: image.description || null,
                    ordering: i
                  });
              }
              console.log(`  🖼️  Synced ${project.gallery.length} images`);
            }

            // Fetch and sync ALL versions (comprehensive - no limit)
            const versionsResponse = await fetch(
              `https://api.modrinth.com/v2/project/${project.id}/version`
            );

            if (versionsResponse.ok) {
              const versions: ModrinthVersion[] = await versionsResponse.json();
              console.log(`  📦 Fetching ${versions.length} versions...`);

              for (const version of versions) {
                // Get primary file with comprehensive details
                const primaryFile = version.files.find(f => f.primary) || version.files[0];

                if (!primaryFile) {
                  console.warn(`    ⚠️  No files found for version ${version.name}`);
                  continue;
                }

                // Upsert version with complete file information
                const { data: modVersion, error: versionError } = await supabase
                  .from('mod_versions')
                  .upsert({
                    modrinth_version_id: version.id,
                    mod_id: mod.id,
                    version_number: version.version_number,
                    name: version.name,
                    changelog: version.changelog || null,
                    published_at: version.date_published,
                    downloads: version.downloads,
                    file_url: primaryFile.url,
                    file_name: primaryFile.filename,
                    file_size: primaryFile.size,
                    file_hash: primaryFile.hashes?.sha1 || null
                  }, { onConflict: 'modrinth_version_id' })
                  .select()
                  .single();

                if (versionError || !modVersion) {
                  console.error(`    ❌ Error syncing version ${version.name}:`, versionError);
                  continue;
                }

                // Sync loaders (Fabric, Forge, NeoForge, Quilt, etc.)
                if (version.loaders && version.loaders.length > 0) {
                  // Delete old loaders for this version
                  await supabase
                    .from('version_loaders')
                    .delete()
                    .eq('version_id', modVersion.id);

                  // Insert new loaders
                  for (const loader of version.loaders) {
                    await supabase
                      .from('version_loaders')
                      .insert({
                        version_id: modVersion.id,
                        loader: loader.toLowerCase()
                      });
                  }
                }

                // Sync game versions (comprehensive)
                if (version.game_versions && version.game_versions.length > 0) {
                  // Delete old game version associations
                  await supabase
                    .from('version_game_versions')
                    .delete()
                    .eq('version_id', modVersion.id);

                  // Insert new game version associations
                  for (const gameVersion of version.game_versions) {
                    // Upsert minecraft version (create if doesn't exist)
                    const { data: mcVersion } = await supabase
                      .from('minecraft_versions')
                      .upsert({
                        version: gameVersion
                      }, { onConflict: 'version' })
                      .select()
                      .single();

                    if (mcVersion) {
                      await supabase
                        .from('version_game_versions')
                        .insert({
                          version_id: modVersion.id,
                          minecraft_version_id: mcVersion.id
                        });
                    }
                  }
                }

                // Sync dependencies (comprehensive)
                if (version.dependencies && version.dependencies.length > 0) {
                  // Delete old dependencies
                  await supabase
                    .from('mod_dependencies')
                    .delete()
                    .eq('version_id', modVersion.id);

                  // Insert new dependencies
                  for (const dep of version.dependencies) {
                    if (dep.project_id) {
                      // Try to find the dependency mod in our database
                      const { data: depMod } = await supabase
                        .from('mods')
                        .select('id')
                        .eq('modrinth_id', dep.project_id)
                        .single();

                      await supabase
                        .from('mod_dependencies')
                        .insert({
                          version_id: modVersion.id,
                          dependency_mod_id: depMod?.id || null,
                          dependency_type: dep.dependency_type || 'required',
                          version_requirement: dep.version_id || null
                        });
                    }
                  }
                }
              }

              console.log(`  ✅ Synced ${versions.length} versions for ${project.title}`);
            }

            typeSynced++;
            totalSynced++;

            // Small delay to avoid rate limiting
            await new Promise(resolve => setTimeout(resolve, 100));
          } catch (error) {
            console.error(`  ❌ Error processing ${type}:`, error);
            typeErrors++;
            totalErrors++;
          }
        }
      } catch (error) {
        console.error(`❌ Error in ${type} sync:`, error);
        typeErrors++;
      }

      syncResults.push({ 
        type, 
        synced: typeSynced, 
        errors: typeErrors,
        total: typeSynced + typeErrors
      });
      
      console.log(`✅ Completed sync for ${type}s: ${typeSynced} synced, ${typeErrors} errors`);
    }

    console.log(`\n🎉 Comprehensive sync completed!`);
    console.log(`📊 Total projects synced: ${totalSynced}`);
    console.log(`❌ Total errors: ${totalErrors}`);

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Comprehensive Modrinth sync completed successfully',
        totalSynced,
        totalErrors,
        syncResults,
        timestamp: new Date().toISOString()
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ Fatal sync error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500
      }
    );
  }
});
