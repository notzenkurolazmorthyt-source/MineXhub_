import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Download } from "lucide-react";
import { Link } from "react-router-dom";

// Loader display info with colors
const loaderInfo: Record<string, { label: string; color: string }> = {
  fabric: { label: "Fabric", color: "bg-amber-500/20 text-amber-400 border-amber-500/30" },
  forge: { label: "Forge", color: "bg-orange-500/20 text-orange-400 border-orange-500/30" },
  quilt: { label: "Quilt", color: "bg-purple-500/20 text-purple-400 border-purple-500/30" },
  neoforge: { label: "NeoForge", color: "bg-red-500/20 text-red-400 border-red-500/30" },
  optifine: { label: "OptiFine", color: "bg-red-600/20 text-red-300 border-red-600/30" },
  iris: { label: "Iris", color: "bg-cyan-500/20 text-cyan-400 border-cyan-500/30" },
  vanilla: { label: "Vanilla", color: "bg-green-500/20 text-green-400 border-green-500/30" },
  paper: { label: "Paper", color: "bg-sky-500/20 text-sky-400 border-sky-500/30" },
  spigot: { label: "Spigot", color: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30" },
  velocity: { label: "Velocity", color: "bg-teal-500/20 text-teal-400 border-teal-500/30" },
  bukkit: { label: "Bukkit", color: "bg-blue-500/20 text-blue-400 border-blue-500/30" },
  purpur: { label: "Purpur", color: "bg-violet-500/20 text-violet-400 border-violet-500/30" },
};

interface ModCardProps {
  id: string;
  slug: string;
  name: string;
  summary: string;
  iconUrl?: string;
  downloads: number;
  modType: string;
  featured?: boolean;
  loaders?: string[];
}

export function ModCard({ id, slug, name, summary, iconUrl, downloads, modType, featured, loaders }: ModCardProps) {
  const formatDownloads = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  return (
    <Link to={`/mod/${slug}`}>
      <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group h-full">
        <div className="aspect-video relative overflow-hidden bg-muted">
          {iconUrl ? (
            <img 
              src={iconUrl} 
              alt={name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <span className="text-6xl opacity-20">📦</span>
            </div>
          )}
          {featured && (
            <Badge className="absolute top-2 right-2 bg-primary">Featured</Badge>
          )}
        </div>
        <div className="p-4 flex flex-col h-[calc(100%-theme(spacing.32))]">
          <div className="flex items-start justify-between gap-2 mb-2">
            <h3 className="font-semibold text-lg line-clamp-1">{name}</h3>
            <Badge variant="secondary" className="shrink-0 text-xs">
              {modType}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground line-clamp-2 mb-3 flex-grow">
            {summary}
          </p>
          
          {/* Loader badges */}
          {loaders && loaders.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-3">
              {loaders.slice(0, 4).map((loader) => {
                const info = loaderInfo[loader] || { label: loader, color: "bg-muted" };
                return (
                  <Badge 
                    key={loader} 
                    variant="outline" 
                    className={`${info.color} text-xs px-1.5 py-0`}
                  >
                    {info.label}
                  </Badge>
                );
              })}
              {loaders.length > 4 && (
                <Badge variant="secondary" className="text-xs px-1.5 py-0">
                  +{loaders.length - 4}
                </Badge>
              )}
            </div>
          )}
          
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Download className="h-4 w-4" />
              <span>{formatDownloads(downloads)}</span>
            </div>
          </div>
        </div>
      </Card>
    </Link>
  );
}
