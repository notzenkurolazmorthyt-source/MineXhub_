import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Download, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import JSZip from 'jszip';
import { toast } from 'sonner';

interface ModpackInstallerProps {
  modpackId: string;
  modpackName: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface ModFile {
  name: string;
  url: string;
  size: number;
  status: 'pending' | 'downloading' | 'complete' | 'error';
  progress: number;
}

export function ModpackInstaller({ modpackId, modpackName, open, onOpenChange }: ModpackInstallerProps) {
  const [installing, setInstalling] = useState(false);
  const [mods, setMods] = useState<ModFile[]>([]);
  const [totalProgress, setTotalProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState<'analyzing' | 'downloading' | 'packaging' | 'complete'>('analyzing');

  const startInstallation = async () => {
    setInstalling(true);
    setCurrentStep('analyzing');

    try {
      // Fetch modpack details and all dependencies
      const { data: modpack, error: modpackError } = await supabase
        .from('mods')
        .select(`
          id,
          name,
          mod_versions (
            id,
            version_number,
            file_url,
            file_name,
            file_size,
            mod_dependencies (
              dependency_type,
              dependency_mod_id,
              mods (
                name,
                mod_versions (
                  id,
                  version_number,
                  file_url,
                  file_name,
                  file_size
                )
              )
            )
          )
        `)
        .eq('id', modpackId)
        .single();

      if (modpackError || !modpack) {
        throw new Error('Failed to fetch modpack details');
      }

      // Get latest version
      const latestVersion = modpack.mod_versions?.[0];
      if (!latestVersion) {
        throw new Error('No versions available for this modpack');
      }

      // Build list of all mods to download
      const modFiles: ModFile[] = [
        {
          name: latestVersion.file_name,
          url: latestVersion.file_url,
          size: latestVersion.file_size,
          status: 'pending',
          progress: 0
        }
      ];

      // Add dependencies (required and optional)
      for (const dep of latestVersion.mod_dependencies || []) {
        if (dep.dependency_type === 'required' || dep.dependency_type === 'optional') {
          const depMod = dep.mods;
          const depVersion = depMod?.mod_versions?.[0];
          
          if (depVersion) {
            modFiles.push({
              name: depVersion.file_name,
              url: depVersion.file_url,
              size: depVersion.file_size,
              status: 'pending',
              progress: 0
            });
          }
        }
      }

      setMods(modFiles);
      setCurrentStep('downloading');

      // Download all mods
      const downloadedBlobs: { name: string; blob: Blob }[] = [];
      
      for (let i = 0; i < modFiles.length; i++) {
        const mod = modFiles[i];
        
        setMods(prev => prev.map((m, idx) => 
          idx === i ? { ...m, status: 'downloading' } : m
        ));

        try {
          const response = await fetch(mod.url);
          const reader = response.body?.getReader();
          const contentLength = mod.size;
          
          if (!reader) throw new Error('Failed to read file');

          let receivedLength = 0;
          const chunks: Uint8Array[] = [];

          while (true) {
            const { done, value } = await reader.read();
            
            if (done) break;
            
            chunks.push(value);
            receivedLength += value.length;

            const progress = (receivedLength / contentLength) * 100;
            setMods(prev => prev.map((m, idx) => 
              idx === i ? { ...m, progress } : m
            ));
          }

          const blob = new Blob(chunks as BlobPart[]);
          downloadedBlobs.push({ name: mod.name, blob });

          setMods(prev => prev.map((m, idx) => 
            idx === i ? { ...m, status: 'complete', progress: 100 } : m
          ));

          setTotalProgress(((i + 1) / modFiles.length) * 100);
        } catch (error) {
          console.error(`Failed to download ${mod.name}:`, error);
          setMods(prev => prev.map((m, idx) => 
            idx === i ? { ...m, status: 'error' } : m
          ));
        }
      }

      // Package into ZIP
      setCurrentStep('packaging');
      const zip = new JSZip();
      
      for (const { name, blob } of downloadedBlobs) {
        zip.file(name, blob);
      }

      // Add installation instructions
      const instructions = `
# ${modpackName} Installation Instructions

## Files Included:
${downloadedBlobs.map(f => `- ${f.name}`).join('\n')}

## Installation Steps:
1. Open your Minecraft launcher
2. Select your Minecraft installation directory
3. Navigate to the "mods" folder (create it if it doesn't exist)
4. Extract all .jar files from this ZIP into the mods folder
5. Launch Minecraft with the correct mod loader (Forge/Fabric/Quilt)

## Important Notes:
- Make sure you have the correct mod loader installed
- Check that your Minecraft version matches the mods' requirements
- Some mods may have additional dependencies - check individual mod pages for details

Enjoy your modpack!
      `;

      zip.file('INSTALLATION.txt', instructions);

      // Generate and download ZIP
      const zipBlob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(zipBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${modpackName.replace(/[^a-z0-9]/gi, '_')}_modpack.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setCurrentStep('complete');
      toast.success('Modpack installed successfully!', {
        description: 'Check your downloads folder for the ZIP file'
      });

    } catch (error) {
      console.error('Installation error:', error);
      toast.error('Installation failed', {
        description: error instanceof Error ? error.message : 'Unknown error occurred'
      });
    } finally {
      setInstalling(false);
    }
  };

  const getStepDescription = () => {
    switch (currentStep) {
      case 'analyzing':
        return 'Analyzing modpack and dependencies...';
      case 'downloading':
        return `Downloading ${mods.length} mods...`;
      case 'packaging':
        return 'Creating installation package...';
      case 'complete':
        return 'Installation complete!';
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Install {modpackName}</DialogTitle>
          <DialogDescription>
            One-click installer will download all mods with dependencies
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {!installing && currentStep === 'analyzing' && (
            <div className="text-center py-8">
              <Download className="h-16 w-16 mx-auto mb-4 text-primary" />
              <p className="text-muted-foreground">
                Click the button below to start the installation process.
                All required mods and dependencies will be downloaded automatically.
              </p>
            </div>
          )}

          {installing && (
            <>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium">{getStepDescription()}</span>
                  <span className="text-muted-foreground">{Math.round(totalProgress)}%</span>
                </div>
                <Progress value={totalProgress} className="h-2" />
              </div>

              {mods.length > 0 && currentStep === 'downloading' && (
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {mods.map((mod, idx) => (
                    <div key={idx} className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                      <div className="flex-shrink-0">
                        {mod.status === 'complete' && <CheckCircle className="h-5 w-5 text-green-500" />}
                        {mod.status === 'downloading' && <Loader2 className="h-5 w-5 animate-spin text-primary" />}
                        {mod.status === 'error' && <AlertCircle className="h-5 w-5 text-destructive" />}
                        {mod.status === 'pending' && <div className="h-5 w-5 rounded-full border-2 border-muted-foreground" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{mod.name}</p>
                        <div className="flex items-center gap-2">
                          <Progress value={mod.progress} className="h-1 flex-1" />
                          <span className="text-xs text-muted-foreground">{Math.round(mod.progress)}%</span>
                        </div>
                      </div>
                      <Badge variant={
                        mod.status === 'complete' ? 'default' :
                        mod.status === 'error' ? 'destructive' :
                        'secondary'
                      }>
                        {mod.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              )}

              {currentStep === 'packaging' && (
                <div className="text-center py-4">
                  <Loader2 className="h-8 w-8 animate-spin mx-auto mb-2 text-primary" />
                  <p className="text-sm text-muted-foreground">Creating installation package...</p>
                </div>
              )}
            </>
          )}

          {currentStep === 'complete' && (
            <div className="text-center py-8">
              <CheckCircle className="h-16 w-16 mx-auto mb-4 text-green-500" />
              <h3 className="text-lg font-semibold mb-2">Installation Complete!</h3>
              <p className="text-sm text-muted-foreground">
                Your modpack has been downloaded. Check your downloads folder for the ZIP file.
                Extract it to your Minecraft mods folder to complete installation.
              </p>
            </div>
          )}
        </div>

        <DialogFooter>
          {!installing && currentStep === 'analyzing' && (
            <Button onClick={startInstallation} size="lg" className="w-full">
              <Download className="h-5 w-5 mr-2" />
              Start Installation
            </Button>
          )}
          {currentStep === 'complete' && (
            <Button onClick={() => onOpenChange(false)} size="lg" className="w-full">
              Close
            </Button>
          )}
          {installing && currentStep !== 'complete' && (
            <Button disabled size="lg" className="w-full">
              <Loader2 className="h-5 w-5 mr-2 animate-spin" />
              Installing...
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
