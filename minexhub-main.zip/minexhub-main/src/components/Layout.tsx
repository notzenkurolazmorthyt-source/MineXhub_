import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useTheme } from "next-themes";
import { Moon, Sun, Upload, User, Menu, X, Home, Compass, Heart, History, LogIn, Coffee, Box, Shield } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export default function Layout({ children }: { children: React.ReactNode }) {
  const { theme, setTheme } = useTheme();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, signOut } = useAuth();

  // Check if user is admin
  const { data: isAdmin } = useQuery({
    queryKey: ["is-admin", user?.id],
    queryFn: async () => {
      if (!user) return false;
      const { data } = await supabase.rpc('has_role', {
        _user_id: user.id,
        _role: 'admin'
      });
      return data || false;
    },
    enabled: !!user,
  });

  const navItems = [
    { path: "/", label: "Home", icon: Home },
    { path: "/explore", label: "Explore", icon: Compass },
    { path: "/explore?edition=java", label: "Java", icon: Coffee },
    { path: "/bedrock", label: "Bedrock", icon: Box },
  ];

  const bottomNavItems = [
    { path: "/", label: "Home", icon: Home },
    { path: "/explore", label: "Explore", icon: Compass },
    { path: "/upload", label: "Upload", icon: Upload },
    { path: "/favorites", label: "Favorites", icon: Heart },
    { path: user ? "/profile" : "/auth", label: user ? "Profile" : "Login", icon: User },
  ];

  return (
    <div className="min-h-screen bg-background pb-16 md:pb-0">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-6">
            <Link to="/" className="flex items-center gap-2">
              <img src="/minexhub-logo.png" alt="MineXhub Logo" className="h-8 w-8 rounded-lg" />
              <span className="hidden font-bold text-xl sm:inline-block">
                Mine<span className="bg-gradient-to-r from-primary via-accent to-destructive bg-clip-text text-transparent">X</span>hub
              </span>
            </Link>
            
            <nav className="hidden md:flex items-center gap-4">
              {navItems.map((item) => {
                const isActive = item.path === "/" 
                  ? location.pathname === "/" 
                  : location.pathname + location.search === item.path || 
                    (item.path === "/explore" && location.pathname === "/explore" && !location.search.includes("edition"));
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`text-sm font-medium transition-colors hover:text-primary flex items-center gap-1.5 px-3 py-1.5 rounded-md ${
                      isActive
                        ? "text-foreground bg-muted"
                        : "text-muted-foreground"
                    }`}
                  >
                    <item.icon className="h-4 w-4" />
                    {item.label}
                  </Link>
                );
              })}
              <Link
                to="/favorites"
                className={`text-sm font-medium transition-colors hover:text-primary flex items-center gap-1.5 px-3 py-1.5 rounded-md ${
                  location.pathname === "/favorites"
                    ? "text-foreground bg-muted"
                    : "text-muted-foreground"
                }`}
              >
                <Heart className="h-4 w-4" />
                Favorites
              </Link>
              <Link
                to="/history"
                className={`text-sm font-medium transition-colors hover:text-primary flex items-center gap-1.5 px-3 py-1.5 rounded-md ${
                  location.pathname === "/history"
                    ? "text-foreground bg-muted"
                    : "text-muted-foreground"
                }`}
              >
                <History className="h-4 w-4" />
                History
              </Link>
              {isAdmin && (
                <Link
                  to="/admin"
                  className={`text-sm font-medium transition-colors hover:text-primary flex items-center gap-1.5 px-3 py-1.5 rounded-md ${
                    location.pathname === "/admin"
                      ? "text-foreground bg-muted"
                      : "text-muted-foreground"
                  }`}
                >
                  <Shield className="h-4 w-4" />
                  Admin
                </Link>
              )}
            </nav>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="hidden sm:inline-flex"
            >
              <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            </Button>
            
            {user ? (
              <>
                <Button variant="outline" size="sm" asChild className="hidden sm:inline-flex bg-gradient-to-r from-primary/10 to-accent/10 border-primary/30 hover:border-primary">
                  <Link to="/upload">
                    <Upload className="h-4 w-4 mr-2" />
                    Upload
                  </Link>
                </Button>
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="hidden md:inline-flex">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={user.user_metadata?.avatar_url} />
                        <AvatarFallback>{user.user_metadata?.username?.[0] || user.email?.[0]?.toUpperCase()}</AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem asChild>
                      <Link to="/profile">Profile</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link to="/favorites">Favorites</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link to="/history">History</Link>
                    </DropdownMenuItem>
                    {isAdmin && (
                      <>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem asChild>
                          <Link to="/admin" className="text-primary">
                            <Shield className="h-4 w-4 mr-2" />
                            Admin Panel
                          </Link>
                        </DropdownMenuItem>
                      </>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => signOut()} className="text-destructive">
                      Sign Out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <Button variant="default" size="sm" asChild className="hidden sm:inline-flex">
                <Link to="/auth">
                  <LogIn className="h-4 w-4 mr-2" />
                  Sign In
                </Link>
              </Button>
            )}

            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? (
                <X className="h-5 w-5" />
              ) : (
                <Menu className="h-5 w-5" />
              )}
            </Button>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-border bg-background">
            <nav className="container mx-auto flex flex-col gap-2 p-4">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`text-sm font-medium transition-colors hover:text-primary flex items-center gap-2 px-3 py-2 rounded-md ${
                    location.pathname === item.path
                      ? "text-foreground bg-muted"
                      : "text-muted-foreground"
                  }`}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </Link>
              ))}
              {user ? (
                <>
                  <Link
                    to="/upload"
                    onClick={() => setMobileMenuOpen(false)}
                    className="text-sm font-medium text-muted-foreground hover:text-primary flex items-center gap-2 px-3 py-2"
                  >
                    <Upload className="h-4 w-4" />
                    Upload
                  </Link>
                  {isAdmin && (
                    <Link
                      to="/admin"
                      onClick={() => setMobileMenuOpen(false)}
                      className="text-sm font-medium text-primary hover:text-primary/80 flex items-center gap-2 px-3 py-2"
                    >
                      <Shield className="h-4 w-4" />
                      Admin Panel
                    </Link>
                  )}
                  <button
                    onClick={() => { signOut(); setMobileMenuOpen(false); }}
                    className="text-sm font-medium text-destructive hover:text-destructive/80 text-left px-3 py-2"
                  >
                    Sign Out
                  </button>
                </>
              ) : (
                <Link
                  to="/auth"
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-sm font-medium text-primary hover:text-primary/80 flex items-center gap-2 px-3 py-2"
                >
                  <LogIn className="h-4 w-4" />
                  Sign In
                </Link>
              )}
            </nav>
          </div>
        )}
      </header>

      {/* Main content */}
      <main>{children}</main>

      {/* Footer - hidden on mobile */}
      <footer className="hidden md:block border-t border-border bg-muted/30 mt-20">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-bold mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">MineXhub</h3>
              <p className="text-sm text-muted-foreground">
                Discover, share, and download the best Minecraft content.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Browse</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link to="/explore?type=mod" className="hover:text-primary">Mods</Link></li>
                <li><Link to="/explore?type=shader" className="hover:text-primary">Shaders</Link></li>
                <li><Link to="/explore?type=resourcepack" className="hover:text-primary">Resource Packs</Link></li>
                <li><Link to="/explore?type=modpack" className="hover:text-primary">Modpacks</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Editions</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link to="/explore?edition=java" className="hover:text-primary">Java Edition</Link></li>
                <li><Link to="/bedrock" className="hover:text-primary">Bedrock Edition</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary">Help Center</a></li>
                <li><a href="#" className="hover:text-primary">Contact</a></li>
                <li><a href="#" className="hover:text-primary">Privacy</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-border text-center text-sm text-muted-foreground">
            © {new Date().getFullYear()} MineXhub. Not affiliated with Mojang or Microsoft.
          </div>
        </div>
      </footer>

      {/* Bottom Navigation - Mobile Only */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-background/95 backdrop-blur border-t border-border">
        <div className="flex items-center justify-around h-16">
          {bottomNavItems.map((item) => {
            const isActive = location.pathname === item.path || 
              (item.path === "/explore" && location.pathname.startsWith("/explore"));
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex flex-col items-center justify-center gap-1 px-3 py-2 transition-colors ${
                  isActive
                    ? "text-primary"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <item.icon className={`h-5 w-5 ${isActive ? "text-primary" : ""}`} />
                <span className="text-xs font-medium">{item.label}</span>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}