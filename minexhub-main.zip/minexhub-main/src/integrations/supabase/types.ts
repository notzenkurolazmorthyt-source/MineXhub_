export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      categories: {
        Row: {
          created_at: string
          description: string | null
          icon: string | null
          id: string
          name: string
          slug: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          name: string
          slug: string
        }
        Update: {
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          name?: string
          slug?: string
        }
        Relationships: []
      }
      download_history: {
        Row: {
          downloaded_at: string
          id: string
          ip_address: string | null
          mod_id: string
          user_agent: string | null
          user_id: string | null
          version_id: string
        }
        Insert: {
          downloaded_at?: string
          id?: string
          ip_address?: string | null
          mod_id: string
          user_agent?: string | null
          user_id?: string | null
          version_id: string
        }
        Update: {
          downloaded_at?: string
          id?: string
          ip_address?: string | null
          mod_id?: string
          user_agent?: string | null
          user_id?: string | null
          version_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "download_history_mod_id_fkey"
            columns: ["mod_id"]
            isOneToOne: false
            referencedRelation: "mods"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "download_history_version_id_fkey"
            columns: ["version_id"]
            isOneToOne: false
            referencedRelation: "mod_versions"
            referencedColumns: ["id"]
          },
        ]
      }
      minecraft_versions: {
        Row: {
          created_at: string
          id: string
          release_date: string | null
          version: string
        }
        Insert: {
          created_at?: string
          id?: string
          release_date?: string | null
          version: string
        }
        Update: {
          created_at?: string
          id?: string
          release_date?: string | null
          version?: string
        }
        Relationships: []
      }
      mod_categories: {
        Row: {
          category_id: string
          id: string
          mod_id: string
        }
        Insert: {
          category_id: string
          id?: string
          mod_id: string
        }
        Update: {
          category_id?: string
          id?: string
          mod_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "mod_categories_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "mod_categories_mod_id_fkey"
            columns: ["mod_id"]
            isOneToOne: false
            referencedRelation: "mods"
            referencedColumns: ["id"]
          },
        ]
      }
      mod_dependencies: {
        Row: {
          created_at: string
          dependency_mod_id: string | null
          dependency_type: string
          id: string
          version_id: string
          version_requirement: string | null
        }
        Insert: {
          created_at?: string
          dependency_mod_id?: string | null
          dependency_type: string
          id?: string
          version_id: string
          version_requirement?: string | null
        }
        Update: {
          created_at?: string
          dependency_mod_id?: string | null
          dependency_type?: string
          id?: string
          version_id?: string
          version_requirement?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "mod_dependencies_dependency_mod_id_fkey"
            columns: ["dependency_mod_id"]
            isOneToOne: false
            referencedRelation: "mods"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "mod_dependencies_version_id_fkey"
            columns: ["version_id"]
            isOneToOne: false
            referencedRelation: "mod_versions"
            referencedColumns: ["id"]
          },
        ]
      }
      mod_images: {
        Row: {
          created_at: string
          description: string | null
          id: string
          mod_id: string
          ordering: number
          title: string | null
          url: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          mod_id: string
          ordering?: number
          title?: string | null
          url: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          mod_id?: string
          ordering?: number
          title?: string | null
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "mod_images_mod_id_fkey"
            columns: ["mod_id"]
            isOneToOne: false
            referencedRelation: "mods"
            referencedColumns: ["id"]
          },
        ]
      }
      mod_reactions: {
        Row: {
          created_at: string
          id: string
          mod_id: string
          reaction_type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          mod_id: string
          reaction_type: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          mod_id?: string
          reaction_type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "mod_reactions_mod_id_fkey"
            columns: ["mod_id"]
            isOneToOne: false
            referencedRelation: "mods"
            referencedColumns: ["id"]
          },
        ]
      }
      mod_tags: {
        Row: {
          id: string
          mod_id: string
          tag_id: string
        }
        Insert: {
          id?: string
          mod_id: string
          tag_id: string
        }
        Update: {
          id?: string
          mod_id?: string
          tag_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "mod_tags_mod_id_fkey"
            columns: ["mod_id"]
            isOneToOne: false
            referencedRelation: "mods"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "mod_tags_tag_id_fkey"
            columns: ["tag_id"]
            isOneToOne: false
            referencedRelation: "tags"
            referencedColumns: ["id"]
          },
        ]
      }
      mod_versions: {
        Row: {
          changelog: string | null
          created_at: string
          downloads: number
          external_url: string | null
          file_hash: string | null
          file_name: string
          file_size: number
          file_url: string
          id: string
          is_external_link: boolean
          mod_id: string
          modrinth_version_id: string | null
          name: string | null
          published_at: string
          version_number: string
        }
        Insert: {
          changelog?: string | null
          created_at?: string
          downloads?: number
          external_url?: string | null
          file_hash?: string | null
          file_name: string
          file_size: number
          file_url: string
          id?: string
          is_external_link?: boolean
          mod_id: string
          modrinth_version_id?: string | null
          name?: string | null
          published_at?: string
          version_number: string
        }
        Update: {
          changelog?: string | null
          created_at?: string
          downloads?: number
          external_url?: string | null
          file_hash?: string | null
          file_name?: string
          file_size?: number
          file_url?: string
          id?: string
          is_external_link?: boolean
          mod_id?: string
          modrinth_version_id?: string | null
          name?: string | null
          published_at?: string
          version_number?: string
        }
        Relationships: [
          {
            foreignKeyName: "mod_versions_mod_id_fkey"
            columns: ["mod_id"]
            isOneToOne: false
            referencedRelation: "mods"
            referencedColumns: ["id"]
          },
        ]
      }
      mods: {
        Row: {
          author_id: string | null
          banner_url: string | null
          created_at: string
          curseforge_id: string | null
          description: string
          discord_url: string | null
          dislikes: number
          downloads: number
          edition: string | null
          featured: boolean
          followers: number
          icon_url: string | null
          id: string
          issues_url: string | null
          last_synced_at: string | null
          likes: number
          mod_type: Database["public"]["Enums"]["mod_type"]
          modrinth_id: string | null
          name: string
          slug: string
          source_url: string | null
          status: Database["public"]["Enums"]["mod_status"]
          summary: string
          updated_at: string
          views: number
          wiki_url: string | null
        }
        Insert: {
          author_id?: string | null
          banner_url?: string | null
          created_at?: string
          curseforge_id?: string | null
          description: string
          discord_url?: string | null
          dislikes?: number
          downloads?: number
          edition?: string | null
          featured?: boolean
          followers?: number
          icon_url?: string | null
          id?: string
          issues_url?: string | null
          last_synced_at?: string | null
          likes?: number
          mod_type?: Database["public"]["Enums"]["mod_type"]
          modrinth_id?: string | null
          name: string
          slug: string
          source_url?: string | null
          status?: Database["public"]["Enums"]["mod_status"]
          summary: string
          updated_at?: string
          views?: number
          wiki_url?: string | null
        }
        Update: {
          author_id?: string | null
          banner_url?: string | null
          created_at?: string
          curseforge_id?: string | null
          description?: string
          discord_url?: string | null
          dislikes?: number
          downloads?: number
          edition?: string | null
          featured?: boolean
          followers?: number
          icon_url?: string | null
          id?: string
          issues_url?: string | null
          last_synced_at?: string | null
          likes?: number
          mod_type?: Database["public"]["Enums"]["mod_type"]
          modrinth_id?: string | null
          name?: string
          slug?: string
          source_url?: string | null
          status?: Database["public"]["Enums"]["mod_status"]
          summary?: string
          updated_at?: string
          views?: number
          wiki_url?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          bio: string | null
          created_at: string
          display_name: string | null
          id: string
          updated_at: string
          username: string
          website: string | null
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          display_name?: string | null
          id: string
          updated_at?: string
          username: string
          website?: string | null
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          display_name?: string | null
          id?: string
          updated_at?: string
          username?: string
          website?: string | null
        }
        Relationships: []
      }
      tags: {
        Row: {
          created_at: string
          id: string
          name: string
          slug: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          slug: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          slug?: string
        }
        Relationships: []
      }
      user_favorites: {
        Row: {
          created_at: string
          id: string
          mod_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          mod_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          mod_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_favorites_mod_id_fkey"
            columns: ["mod_id"]
            isOneToOne: false
            referencedRelation: "mods"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      version_game_versions: {
        Row: {
          id: string
          minecraft_version_id: string
          version_id: string
        }
        Insert: {
          id?: string
          minecraft_version_id: string
          version_id: string
        }
        Update: {
          id?: string
          minecraft_version_id?: string
          version_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "version_game_versions_minecraft_version_id_fkey"
            columns: ["minecraft_version_id"]
            isOneToOne: false
            referencedRelation: "minecraft_versions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "version_game_versions_version_id_fkey"
            columns: ["version_id"]
            isOneToOne: false
            referencedRelation: "mod_versions"
            referencedColumns: ["id"]
          },
        ]
      }
      version_loaders: {
        Row: {
          id: string
          loader: Database["public"]["Enums"]["loader_type"]
          version_id: string
        }
        Insert: {
          id?: string
          loader: Database["public"]["Enums"]["loader_type"]
          version_id: string
        }
        Update: {
          id?: string
          loader?: Database["public"]["Enums"]["loader_type"]
          version_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "version_loaders_version_id_fkey"
            columns: ["version_id"]
            isOneToOne: false
            referencedRelation: "mod_versions"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
      loader_type:
        | "fabric"
        | "forge"
        | "quilt"
        | "neoforge"
        | "optifine"
        | "iris"
        | "vanilla"
        | "paper"
        | "spigot"
        | "velocity"
        | "bukkit"
        | "purpur"
      mod_status: "approved" | "pending" | "rejected" | "draft"
      mod_type:
        | "mod"
        | "resourcepack"
        | "shader"
        | "plugin"
        | "datapack"
        | "modpack"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
      loader_type: [
        "fabric",
        "forge",
        "quilt",
        "neoforge",
        "optifine",
        "iris",
        "vanilla",
        "paper",
        "spigot",
        "velocity",
        "bukkit",
        "purpur",
      ],
      mod_status: ["approved", "pending", "rejected", "draft"],
      mod_type: [
        "mod",
        "resourcepack",
        "shader",
        "plugin",
        "datapack",
        "modpack",
      ],
    },
  },
} as const
