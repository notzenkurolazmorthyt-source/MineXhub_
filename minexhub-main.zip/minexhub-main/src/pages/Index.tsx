import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { Download, Star, TrendingUp, Package, Brush, Sparkles, Puzzle, Smartphone, Gamepad2, Monitor, ArrowRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ModCard } from "@/components/ModCard";

const javaCategories = [
  { name: "Mods", icon: Package, count: "45K+", color: "text-amber-400", href: "/java?type=mod" },
  { name: "Shaders", icon: Sparkles, count: "3K+", color: "text-cyan-400", href: "/java?type=shader" },
  { name: "Resource Packs", icon: Brush, count: "12K+", color: "text-purple-400", href: "/java?type=resourcepack" },
  { name: "Plugins", icon: Package, count: "8K+", color: "text-sky-400", href: "/java?type=plugin" },
];

const bedrockCategories = [
  { name: "Add-ons", icon: Puzzle, count: "2.5K+", color: "text-emerald-400", href: "/bedrock-explore?type=mod" },
  { name: "Texture Packs", icon: Brush, count: "1.8K+", color: "text-pink-400", href: "/bedrock-explore?type=resourcepack" },
  { name: "Shaders", icon: Sparkles, count: "500+", color: "text-cyan-400", href: "/bedrock-explore?type=shader" },
  { name: "Worlds", icon: Package, count: "1K+", color: "text-orange-400", href: "/bedrock-explore?type=modpack" },
];

export default function Index() {
  const { data: featuredMods } = useQuery({
    queryKey: ["featured-mods"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("mods")
        .select("*")
        .eq("status", "approved")
        .eq("featured", true)
        .order("downloads", { ascending: false })
        .limit(3);
      
      if (error) throw error;
      return data || [];
    },
  });

  const { data: stats } = useQuery({
    queryKey: ["platform-stats"],
    queryFn: async () => {
      const { count: modsCount } = await supabase
        .from("mods")
        .select("*", { count: "exact", head: true })
        .eq("status", "approved");
      
      const { data: downloadsData } = await supabase
        .from("mods")
        .select("downloads")
        .eq("status", "approved");
      
      const totalDownloads = downloadsData?.reduce((sum, mod) => sum + mod.downloads, 0) || 0;
      
      return {
        totalMods: modsCount || 0,
        totalDownloads,
      };
    },
  });

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-accent/5 to-background" />
        <div className="container mx-auto px-4 py-16 relative">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <Badge className="bg-primary/20 text-primary hover:bg-primary/30">
              <TrendingUp className="h-3 w-3 mr-1" />
              Trusted by 10M+ players
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight">
              Discover Amazing
              <span className="text-primary"> Minecraft Content</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Browse thousands of mods, shaders, resource packs, and worlds. All for Java and Bedrock editions.
            </p>
          </div>
        </div>
      </section>

      {/* Edition Selection - Large Buttons */}
      <section className="container mx-auto px-4 py-12">
        <div className="text-center mb-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-3">Choose Your Edition</h2>
          <p className="text-muted-foreground text-lg">Select your Minecraft version to explore content</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {/* Java Edition */}
          <Link to="/java" className="block group">
            <Card className="relative overflow-hidden p-10 hover:shadow-2xl transition-all duration-300 hover:scale-[1.02] cursor-pointer border-2 border-transparent hover:border-amber-500/50 bg-gradient-to-br from-amber-950/20 to-background">
              <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-bl from-amber-500/20 to-transparent rounded-bl-full" />
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-amber-500/10 to-transparent rounded-tr-full" />
              
              <div className="relative z-10">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-20 h-20 rounded-2xl bg-amber-600/20 flex items-center justify-center border border-amber-500/30 group-hover:scale-110 transition-transform">
                    <span className="text-4xl">☕</span>
                  </div>
                  <div>
                    <h3 className="text-3xl font-bold">Java Edition</h3>
                    <Badge variant="secondary" className="mt-2 bg-amber-500/20 text-amber-300 border-amber-500/30">
                      PC / Mac / Linux
                    </Badge>
                  </div>
                </div>
                
                <p className="text-muted-foreground mb-6 text-lg">
                  The original Minecraft experience with extensive modding support. Fabric, Forge, Quilt & more.
                </p>
                
                <div className="flex flex-wrap gap-2 mb-6">
                  {javaCategories.map(cat => (
                    <Badge key={cat.name} variant="outline" className="bg-amber-500/10 border-amber-500/30 text-amber-200">
                      {cat.name}
                    </Badge>
                  ))}
                </div>
                
                <div className="flex items-center text-amber-400 font-semibold group-hover:translate-x-2 transition-transform">
                  <span>Explore Java Content</span>
                  <ArrowRight className="h-5 w-5 ml-2" />
                </div>
              </div>
            </Card>
          </Link>

          {/* Bedrock Edition */}
          <Link to="/bedrock-explore" className="block group">
            <Card className="relative overflow-hidden p-10 hover:shadow-2xl transition-all duration-300 hover:scale-[1.02] cursor-pointer border-2 border-transparent hover:border-emerald-500/50 bg-gradient-to-br from-emerald-950/20 to-background">
              <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-bl from-emerald-500/20 to-transparent rounded-bl-full" />
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-emerald-500/10 to-transparent rounded-tr-full" />
              
              <div className="relative z-10">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-20 h-20 rounded-2xl bg-emerald-600/20 flex items-center justify-center border border-emerald-500/30 group-hover:scale-110 transition-transform">
                    <span className="text-4xl">🪨</span>
                  </div>
                  <div>
                    <h3 className="text-3xl font-bold">Bedrock Edition</h3>
                    <Badge variant="secondary" className="mt-2 bg-emerald-500/20 text-emerald-300 border-emerald-500/30">
                      Mobile / Console / Windows 10+
                    </Badge>
                  </div>
                </div>
                
                <p className="text-muted-foreground mb-6 text-lg">
                  Cross-platform Minecraft with addon support. Play on mobile, Xbox, PlayStation, Switch & PC.
                </p>
                
                <div className="flex flex-wrap gap-2 mb-6">
                  {bedrockCategories.map(cat => (
                    <Badge key={cat.name} variant="outline" className="bg-emerald-500/10 border-emerald-500/30 text-emerald-200">
                      {cat.name}
                    </Badge>
                  ))}
                </div>
                
                <div className="flex items-center gap-4 mb-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Smartphone className="h-4 w-4" />
                    <span>Mobile</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Gamepad2 className="h-4 w-4" />
                    <span>Console</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Monitor className="h-4 w-4" />
                    <span>Windows</span>
                  </div>
                </div>
                
                <div className="flex items-center text-emerald-400 font-semibold group-hover:translate-x-2 transition-transform">
                  <span>Explore Bedrock Content</span>
                  <ArrowRight className="h-5 w-5 ml-2" />
                </div>
              </div>
            </Card>
          </Link>
        </div>
      </section>

      {/* Quick Categories */}
      <section className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Java Categories */}
          <div>
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <span className="text-amber-400">☕</span> Java Categories
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {javaCategories.map((category) => (
                <Link key={category.name} to={category.href}>
                  <Card className="p-4 hover:shadow-lg transition-all hover:scale-105 cursor-pointer border hover:border-amber-500/50">
                    <category.icon className={`h-6 w-6 mb-2 ${category.color}`} />
                    <h4 className="font-semibold">{category.name}</h4>
                    <p className="text-sm text-muted-foreground">{category.count}</p>
                  </Card>
                </Link>
              ))}
            </div>
          </div>

          {/* Bedrock Categories */}
          <div>
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <span className="text-emerald-400">🪨</span> Bedrock Categories
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {bedrockCategories.map((category) => (
                <Link key={category.name} to={category.href}>
                  <Card className="p-4 hover:shadow-lg transition-all hover:scale-105 cursor-pointer border hover:border-emerald-500/50">
                    <category.icon className={`h-6 w-6 mb-2 ${category.color}`} />
                    <h4 className="font-semibold">{category.name}</h4>
                    <p className="text-sm text-muted-foreground">{category.count}</p>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Featured Content */}
      <section className="container mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold">Featured Content</h2>
            <p className="text-muted-foreground mt-1">Most popular downloads this week</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" asChild>
              <Link to="/java">View Java</Link>
            </Button>
            <Button variant="outline" asChild>
              <Link to="/bedrock-explore">View Bedrock</Link>
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredMods && featuredMods.length > 0 ? (
            featuredMods.map((mod) => (
              <ModCard
                key={mod.id}
                id={mod.id}
                slug={mod.slug}
                name={mod.name}
                summary={mod.summary}
                iconUrl={mod.icon_url || undefined}
                downloads={mod.downloads}
                modType={mod.mod_type}
                featured={mod.featured}
              />
            ))
          ) : (
            <div className="col-span-3 text-center py-12">
              <p className="text-muted-foreground">No featured content available yet.</p>
            </div>
          )}
        </div>
      </section>

      {/* Stats */}
      <section className="bg-muted/30 py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-primary">{stats?.totalMods || 0}+</div>
              <div className="text-sm text-muted-foreground mt-2">Total Content</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-accent">
                {stats?.totalDownloads ? 
                  stats.totalDownloads >= 1000000 
                    ? `${(stats.totalDownloads / 1000000).toFixed(0)}M+` 
                    : `${(stats.totalDownloads / 1000).toFixed(0)}K+`
                  : '0'}
              </div>
              <div className="text-sm text-muted-foreground mt-2">Downloads</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-amber-400">2M+</div>
              <div className="text-sm text-muted-foreground mt-2">Active Users</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-emerald-400">50K+</div>
              <div className="text-sm text-muted-foreground mt-2">Creators</div>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
