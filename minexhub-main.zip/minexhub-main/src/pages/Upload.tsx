import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Upload as UploadIcon, Image, X, CheckCircle2, Loader2, Link as LinkIcon, FileUp } from "lucide-react";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

const ALLOWED_FILE_TYPES = [".jar", ".zip", ".mcworld", ".mcpack", ".mcaddon"];
const ALLOWED_IMAGE_TYPES = ["image/png", "image/jpeg", "image/webp"];
const MAX_FILE_SIZE = 100 * 1024 * 1024; // 100MB
const MAX_IMAGE_SIZE = 5 * 1024 * 1024; // 5MB

// Loader options based on content type
const LOADER_OPTIONS: Record<string, { value: string; label: string }[]> = {
  mod: [
    { value: "fabric", label: "Fabric" },
    { value: "forge", label: "Forge" },
    { value: "quilt", label: "Quilt" },
    { value: "neoforge", label: "NeoForge" },
  ],
  shader: [
    { value: "optifine", label: "OptiFine" },
    { value: "iris", label: "Iris" },
  ],
  resourcepack: [
    { value: "vanilla", label: "Vanilla" },
  ],
  texture: [
    { value: "vanilla", label: "Vanilla" },
  ],
  datapack: [
    { value: "vanilla", label: "Vanilla" },
  ],
  plugin: [
    { value: "paper", label: "Paper" },
    { value: "spigot", label: "Spigot" },
    { value: "velocity", label: "Velocity" },
    { value: "bukkit", label: "Bukkit" },
    { value: "purpur", label: "Purpur" },
  ],
  world: [],
  addon: [],
  skin: [],
};

const uploadSchema = z.object({
  title: z.string()
    .trim()
    .min(3, "Title must be at least 3 characters")
    .max(100, "Title must be less than 100 characters"),
  contentType: z.enum(["mod", "shader", "resourcepack", "world", "addon", "datapack", "texture", "skin", "plugin"], {
    required_error: "Please select a content type",
  }),
  edition: z.enum(["java", "bedrock", "both"], {
    required_error: "Please select a game edition",
  }),
  loaders: z.array(z.string()).optional(),
  mcVersions: z.array(z.string()).min(1, "Please select at least one Minecraft version"),
  description: z.string()
    .trim()
    .min(10, "Description must be at least 10 characters")
    .max(10000, "Description must be less than 10,000 characters"),
  summary: z.string()
    .trim()
    .min(10, "Summary must be at least 10 characters")
    .max(200, "Summary must be less than 200 characters"),
  version: z.string()
    .trim()
    .regex(/^\d+\.\d+(\.\d+)?$/, "Version must be in format X.Y or X.Y.Z (e.g., 1.0 or 1.0.0)"),
  changelog: z.string().max(5000, "Changelog must be less than 5,000 characters").optional(),
  tags: z.string().max(500, "Tags must be less than 500 characters").optional(),
  license: z.string({
    required_error: "Please select a license",
  }),
  downloadType: z.enum(["file", "link"], {
    required_error: "Please select download type",
  }),
  externalUrl: z.string().url("Please enter a valid URL").optional().or(z.literal("")),
});

type UploadFormData = z.infer<typeof uploadSchema>;

// Map content types to mod_type enum
const contentTypeToModType: Record<string, "mod" | "shader" | "resourcepack" | "datapack" | "modpack" | "plugin"> = {
  mod: "mod",
  shader: "shader",
  resourcepack: "resourcepack",
  world: "resourcepack",
  addon: "mod",
  datapack: "datapack",
  texture: "resourcepack",
  skin: "resourcepack",
  plugin: "plugin",
};

export default function Upload() {
  const { toast } = useToast();
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [contentFile, setContentFile] = useState<File | null>(null);
  const [images, setImages] = useState<File[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [fileError, setFileError] = useState<string | null>(null);
  const [imageError, setImageError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Redirect to auth if not logged in
  useEffect(() => {
    if (!authLoading && !user) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to upload content.",
        variant: "destructive",
      });
      navigate("/auth");
    }
  }, [user, authLoading, navigate, toast]);

  // Fetch categories from database
  const { data: categories } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("categories")
        .select("*")
        .order("name");
      if (error) throw error;
      return data || [];
    },
  });

  // Fetch minecraft versions
  const { data: mcVersions } = useQuery({
    queryKey: ["minecraft-versions"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("minecraft_versions")
        .select("*")
        .order("release_date", { ascending: false });
      if (error) throw error;
      return data || [];
    },
  });

  const form = useForm<UploadFormData>({
    resolver: zodResolver(uploadSchema),
    defaultValues: {
      title: "",
      description: "",
      summary: "",
      version: "",
      changelog: "",
      tags: "",
      downloadType: "file",
      externalUrl: "",
      loaders: [],
      mcVersions: [],
    },
  });

  const downloadType = form.watch("downloadType");
  const contentType = form.watch("contentType");
  const selectedLoaders = form.watch("loaders") || [];
  
  // Get available loaders for selected content type
  const availableLoaders = contentType ? LOADER_OPTIONS[contentType] || [] : [];

  const toggleLoader = (loaderValue: string) => {
    const current = form.getValues("loaders") || [];
    if (current.includes(loaderValue)) {
      form.setValue("loaders", current.filter(l => l !== loaderValue));
    } else {
      form.setValue("loaders", [...current, loaderValue]);
    }
  };

  const selectedMcVersions = form.watch("mcVersions") || [];

  const toggleMcVersion = (version: string) => {
    const current = form.getValues("mcVersions") || [];
    if (current.includes(version)) {
      form.setValue("mcVersions", current.filter(v => v !== version));
    } else {
      form.setValue("mcVersions", [...current, version]);
    }
  };

  const validateContentFile = (file: File): boolean => {
    const extension = "." + file.name.split(".").pop()?.toLowerCase();
    if (!ALLOWED_FILE_TYPES.includes(extension)) {
      setFileError(`Invalid file type. Allowed: ${ALLOWED_FILE_TYPES.join(", ")}`);
      return false;
    }
    if (file.size > MAX_FILE_SIZE) {
      setFileError("File size must be less than 100MB");
      return false;
    }
    setFileError(null);
    return true;
  };

  const validateImageFile = (file: File): boolean => {
    if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
      setImageError("Invalid image type. Allowed: PNG, JPG, WebP");
      return false;
    }
    if (file.size > MAX_IMAGE_SIZE) {
      setImageError("Each image must be less than 5MB");
      return false;
    }
    return true;
  };

  const handleContentFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && validateContentFile(file)) {
      setContentFile(file);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (images.length + files.length > 5) {
      setImageError("Maximum 5 images allowed");
      return;
    }
    
    const validFiles = files.filter(validateImageFile);
    if (validFiles.length > 0) {
      setImages(prev => [...prev, ...validFiles]);
      setImageError(null);
    }
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const toggleCategory = (categoryId: string) => {
    setSelectedCategories(prev => 
      prev.includes(categoryId) 
        ? prev.filter(c => c !== categoryId)
        : [...prev, categoryId]
    );
  };

  const generateSlug = (title: string): string => {
    return title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "")
      .substring(0, 64);
  };

  const onSubmit = async (data: UploadFormData) => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to upload content.",
        variant: "destructive",
      });
      return;
    }

    // Validate based on download type
    if (data.downloadType === "file" && !contentFile) {
      setFileError("Please upload a content file");
      return;
    }

    if (data.downloadType === "link" && !data.externalUrl) {
      form.setError("externalUrl", { message: "Please enter an external download URL" });
      return;
    }

    setIsSubmitting(true);

    try {
      const slug = generateSlug(data.title);
      const modType = contentTypeToModType[data.contentType];

      // 1. Create the mod entry first
      const { data: modData, error: modError } = await supabase
        .from("mods")
        .insert([{
          name: data.title,
          slug: `${slug}-${Date.now()}`,
          summary: data.summary,
          description: data.description,
          mod_type: modType,
          author_id: user.id,
          status: "pending" as const,
          edition: data.edition,
        }])
        .select()
        .single();

      if (modError) throw modError;
      const mod = modData;

      let fileUrl = "";
      let fileName = "";
      let fileSize = 0;

      // 2. Handle file upload or external link
      if (data.downloadType === "file" && contentFile) {
        const fileExt = contentFile.name.split(".").pop();
        const filePath = `${user.id}/${mod.id}/${data.version}.${fileExt}`;
        
        const { error: fileUploadError } = await supabase.storage
          .from("mod-files")
          .upload(filePath, contentFile);

        if (fileUploadError) throw fileUploadError;

        const { data: fileUrlData } = supabase.storage
          .from("mod-files")
          .getPublicUrl(filePath);

        fileUrl = fileUrlData.publicUrl;
        fileName = contentFile.name;
        fileSize = contentFile.size;
      } else if (data.downloadType === "link") {
        fileUrl = data.externalUrl || "";
        fileName = "External Download";
        fileSize = 0;
      }

      // 3. Create mod version
      const { data: modVersion, error: versionError } = await supabase
        .from("mod_versions")
        .insert([{
          mod_id: mod.id,
          version_number: data.version,
          name: `Version ${data.version}`,
          changelog: data.changelog || null,
          file_url: fileUrl,
          file_name: fileName,
          file_size: fileSize,
          is_external_link: data.downloadType === "link",
          external_url: data.downloadType === "link" ? data.externalUrl : null,
        }])
        .select()
        .single();

      if (versionError) throw versionError;

      // 4. Add loaders
      const loaders = data.loaders || [];
      for (const loader of loaders) {
        await supabase.from("version_loaders").insert([{
          version_id: modVersion.id,
          loader: loader as any,
        }]);
      }

      // 5. Add Minecraft versions
      const mcVersionsToAdd = data.mcVersions || [];
      for (const mcVer of mcVersionsToAdd) {
        // Find the minecraft_version_id
        const { data: mcVersionData } = await supabase
          .from("minecraft_versions")
          .select("id")
          .eq("version", mcVer)
          .maybeSingle();
        
        if (mcVersionData) {
          await supabase.from("version_game_versions").insert([{
            version_id: modVersion.id,
            minecraft_version_id: mcVersionData.id,
          }]);
        }
      }

      // 6. Upload images
      for (let i = 0; i < images.length; i++) {
        const img = images[i];
        const imgExt = img.name.split(".").pop();
        const imgPath = `${user.id}/${mod.id}/${Date.now()}-${i}.${imgExt}`;
        
        const { error: imgUploadError } = await supabase.storage
          .from("mod-images")
          .upload(imgPath, img);

        if (imgUploadError) {
          console.error("Image upload error:", imgUploadError);
          continue;
        }

        const { data: imgUrlData } = supabase.storage
          .from("mod-images")
          .getPublicUrl(imgPath);

        await supabase.from("mod_images").insert([{
          mod_id: mod.id,
          url: imgUrlData.publicUrl,
          ordering: i,
        }]);

        if (i === 0) {
          await supabase
            .from("mods")
            .update({ icon_url: imgUrlData.publicUrl })
            .eq("id", mod.id);
        }
      }

      // 7. Add categories
      for (const categoryId of selectedCategories) {
        await supabase.from("mod_categories").insert([{
          mod_id: mod.id,
          category_id: categoryId,
        }]);
      }

      toast({
        title: "Upload Successful!",
        description: "Your content has been submitted for review.",
      });

      navigate(`/mod/${mod.slug}`);
    } catch (error: any) {
      console.error("Upload error:", error);
      toast({
        title: "Upload Failed",
        description: error.message || "An error occurred while uploading.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (authLoading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-20 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Upload Content</h1>
          <p className="text-muted-foreground">
            Share your creation with the Minecraft community
          </p>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <Card className="p-6 space-y-6">
              {/* Basic Info */}
              <div className="space-y-4">
                <h2 className="text-xl font-semibold">Basic Information</h2>
                
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title *</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter content title" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="summary"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Summary *</FormLabel>
                      <FormControl>
                        <Input placeholder="A brief summary of your content (max 200 characters)" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="contentType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Content Type *</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="mod">Mod</SelectItem>
                            <SelectItem value="shader">Shader</SelectItem>
                            <SelectItem value="resourcepack">Resource Pack</SelectItem>
                            <SelectItem value="plugin">Plugin</SelectItem>
                            <SelectItem value="world">World</SelectItem>
                            <SelectItem value="addon">Add-on (Bedrock)</SelectItem>
                            <SelectItem value="datapack">Datapack</SelectItem>
                            <SelectItem value="texture">Texture Pack</SelectItem>
                            <SelectItem value="skin">Skin</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="edition"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Game Edition *</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select edition" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="java">☕ Java Edition</SelectItem>
                            <SelectItem value="bedrock">🪨 Bedrock Edition</SelectItem>
                            <SelectItem value="both">📦 Both Editions</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Loader/Platform Selection */}
                {availableLoaders.length > 0 && (
                  <div className="space-y-3">
                    <Label>Supported Loaders/Platforms *</Label>
                    <div className="flex flex-wrap gap-2">
                      {availableLoaders.map((loader) => (
                        <Button
                          key={loader.value}
                          type="button"
                          variant={selectedLoaders.includes(loader.value) ? "default" : "outline"}
                          size="sm"
                          onClick={() => toggleLoader(loader.value)}
                          className="gap-2"
                        >
                          {selectedLoaders.includes(loader.value) && (
                            <CheckCircle2 className="h-4 w-4" />
                          )}
                          {loader.label}
                        </Button>
                      ))}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Select all compatible loaders/platforms for your content
                    </p>
                  </div>
                )}

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description *</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describe your content in detail..."
                          rows={5}
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Version Info */}
              <div className="space-y-4 pt-4 border-t border-border">
                <h2 className="text-xl font-semibold">Version Information</h2>
                
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="version"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Content Version *</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., 1.0.0" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Multiple Minecraft Version Selection */}
                  <div className="space-y-3">
                    <Label>Minecraft Versions *</Label>
                    <p className="text-sm text-muted-foreground">
                      Select all Minecraft versions your content is compatible with
                    </p>
                    
                    {/* Popular versions quick select */}
                    <div className="space-y-2">
                      <p className="text-xs font-medium text-muted-foreground uppercase">Popular Versions</p>
                      <div className="flex flex-wrap gap-2">
                        {['1.21', '1.20.6', '1.20.4', '1.20.1', '1.19.4', '1.18.2', '1.16.5', '1.12.2'].map(ver => (
                          <Button
                            key={ver}
                            type="button"
                            variant={selectedMcVersions.includes(ver) ? "default" : "outline"}
                            size="sm"
                            onClick={() => toggleMcVersion(ver)}
                            className="gap-1 font-mono"
                          >
                            {selectedMcVersions.includes(ver) && (
                              <CheckCircle2 className="h-3 w-3" />
                            )}
                            {ver}
                          </Button>
                        ))}
                      </div>
                    </div>

                    {/* All versions dropdown */}
                    <div className="space-y-2">
                      <p className="text-xs font-medium text-muted-foreground uppercase">All Versions</p>
                      <div className="max-h-40 overflow-y-auto border rounded-lg p-2 space-y-1">
                        {mcVersions && mcVersions.length > 0 ? (
                          mcVersions.map((v) => (
                            <label
                              key={v.id}
                              className="flex items-center gap-2 cursor-pointer hover:bg-muted p-2 rounded text-sm"
                            >
                              <input
                                type="checkbox"
                                checked={selectedMcVersions.includes(v.version)}
                                onChange={() => toggleMcVersion(v.version)}
                                className="rounded border-input"
                              />
                              <span className="font-mono">{v.version}</span>
                            </label>
                          ))
                        ) : (
                          <p className="text-sm text-muted-foreground p-2">Loading versions...</p>
                        )}
                      </div>
                    </div>

                    {/* Selected versions display */}
                    {selectedMcVersions.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        <span className="text-xs text-muted-foreground mr-1">Selected:</span>
                        {selectedMcVersions.map(ver => (
                          <Badge key={ver} variant="secondary" className="gap-1 text-xs">
                            {ver}
                            <X 
                              className="h-3 w-3 cursor-pointer" 
                              onClick={() => toggleMcVersion(ver)} 
                            />
                          </Badge>
                        ))}
                      </div>
                    )}
                    
                    {form.formState.errors.mcVersions && (
                      <p className="text-sm text-destructive">{form.formState.errors.mcVersions.message}</p>
                    )}
                  </div>
                </div>

                <FormField
                  control={form.control}
                  name="changelog"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Changelog</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="What's new in this version?"
                          rows={3}
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Download Type Selection */}
              <div className="space-y-4 pt-4 border-t border-border">
                <h2 className="text-xl font-semibold">Download Method</h2>
                
                <FormField
                  control={form.control}
                  name="downloadType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>How will users download your content? *</FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2"
                        >
                          <div>
                            <RadioGroupItem
                              value="file"
                              id="file"
                              className="peer sr-only"
                            />
                            <Label
                              htmlFor="file"
                              className="flex flex-col items-center justify-between rounded-lg border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer"
                            >
                              <FileUp className="mb-3 h-8 w-8 text-minecraft-grass" />
                              <span className="font-semibold">Upload File</span>
                              <span className="text-sm text-muted-foreground text-center mt-1">
                                Host the file directly on MineHub (Direct download)
                              </span>
                            </Label>
                          </div>
                          <div>
                            <RadioGroupItem
                              value="link"
                              id="link"
                              className="peer sr-only"
                            />
                            <Label
                              htmlFor="link"
                              className="flex flex-col items-center justify-between rounded-lg border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer"
                            >
                              <LinkIcon className="mb-3 h-8 w-8 text-minecraft-diamond" />
                              <span className="font-semibold">External Link</span>
                              <span className="text-sm text-muted-foreground text-center mt-1">
                                Redirect users to an external download page
                              </span>
                            </Label>
                          </div>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* File Upload Section */}
                {downloadType === "file" && (
                  <div className="space-y-4 mt-4">
                    <input
                      type="file"
                      id="contentFile"
                      className="hidden"
                      accept={ALLOWED_FILE_TYPES.join(",")}
                      onChange={handleContentFileChange}
                    />
                    <label
                      htmlFor="contentFile"
                      className={`border-2 border-dashed rounded-lg p-8 text-center hover:border-primary transition cursor-pointer block ${
                        contentFile ? "border-minecraft-grass bg-minecraft-grass/10" : "border-border"
                      }`}
                    >
                      {contentFile ? (
                        <div className="flex items-center justify-center gap-3">
                          <CheckCircle2 className="h-8 w-8 text-minecraft-grass" />
                          <div className="text-left">
                            <p className="font-medium">{contentFile.name}</p>
                            <p className="text-sm text-muted-foreground">
                              {(contentFile.size / 1024 / 1024).toFixed(2)} MB
                            </p>
                          </div>
                        </div>
                      ) : (
                        <>
                          <UploadIcon className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                          <p className="font-medium mb-1">Upload Content File</p>
                          <p className="text-sm text-muted-foreground mb-4">
                            {ALLOWED_FILE_TYPES.join(", ")} (Max 100MB)
                          </p>
                          <Button type="button" variant="outline">Choose File</Button>
                        </>
                      )}
                    </label>
                    {fileError && <p className="text-sm text-destructive mt-2">{fileError}</p>}
                  </div>
                )}

                {/* External Link Section */}
                {downloadType === "link" && (
                  <FormField
                    control={form.control}
                    name="externalUrl"
                    render={({ field }) => (
                      <FormItem className="mt-4">
                        <FormLabel>External Download URL *</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="https://example.com/download/your-file" 
                            {...field} 
                          />
                        </FormControl>
                        <p className="text-sm text-muted-foreground">
                          Enter the URL where users will be redirected to download your content (e.g., Mediafire, Google Drive, CurseForge, etc.)
                        </p>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
              </div>

              {/* Images */}
              <div className="space-y-4 pt-4 border-t border-border">
                <h2 className="text-xl font-semibold">Images</h2>
                
                <div>
                  <input
                    type="file"
                    id="images"
                    className="hidden"
                    accept={ALLOWED_IMAGE_TYPES.join(",")}
                    multiple
                    onChange={handleImageChange}
                  />
                  <label
                    htmlFor="images"
                    className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary transition cursor-pointer block"
                  >
                    <Image className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                    <p className="font-medium mb-1">Upload Images</p>
                    <p className="text-sm text-muted-foreground mb-4">
                      PNG, JPG, WebP (Max 5 images, 5MB each)
                    </p>
                    <Button type="button" variant="outline">Choose Images</Button>
                  </label>
                  {imageError && <p className="text-sm text-destructive mt-2">{imageError}</p>}
                  
                  {images.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-4">
                      {images.map((img, index) => (
                        <div key={index} className="relative">
                          <img
                            src={URL.createObjectURL(img)}
                            alt={`Preview ${index + 1}`}
                            className="h-20 w-20 object-cover rounded-lg"
                          />
                          <button
                            type="button"
                            onClick={() => removeImage(index)}
                            className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Tags & Categories */}
              <div className="space-y-4 pt-4 border-t border-border">
                <h2 className="text-xl font-semibold">Tags & Categories</h2>
                
                <FormField
                  control={form.control}
                  name="tags"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tags</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="performance, graphics, adventure (comma separated)"
                          {...field}
                        />
                      </FormControl>
                      <p className="text-sm text-muted-foreground">
                        Add relevant tags to help users find your content
                      </p>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {categories && categories.length > 0 && (
                  <div className="space-y-3">
                    <Label>Categories (select all that apply)</Label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {categories.map((category) => (
                        <div key={category.id} className="flex items-center space-x-2">
                          <Checkbox
                            id={category.id}
                            checked={selectedCategories.includes(category.id)}
                            onCheckedChange={() => toggleCategory(category.id)}
                          />
                          <label
                            htmlFor={category.id}
                            className="text-sm cursor-pointer"
                          >
                            {category.name}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* License */}
              <div className="space-y-4 pt-4 border-t border-border">
                <h2 className="text-xl font-semibold">License</h2>
                
                <FormField
                  control={form.control}
                  name="license"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>License Type *</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select license" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="all-rights">All Rights Reserved</SelectItem>
                          <SelectItem value="mit">MIT License</SelectItem>
                          <SelectItem value="gpl">GPL-3.0</SelectItem>
                          <SelectItem value="cc-by">CC BY 4.0</SelectItem>
                          <SelectItem value="cc-by-sa">CC BY-SA 4.0</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Submit */}
              <div className="flex justify-end gap-3 pt-4 border-t border-border">
                <Button type="button" variant="outline" disabled={isSubmitting}>
                  Save as Draft
                </Button>
                <Button type="submit" size="lg" disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                      Uploading...
                    </>
                  ) : (
                    <>
                      <UploadIcon className="h-5 w-5 mr-2" />
                      Publish Content
                    </>
                  )}
                </Button>
              </div>
            </Card>
          </form>
        </Form>
      </div>
    </Layout>
  );
}