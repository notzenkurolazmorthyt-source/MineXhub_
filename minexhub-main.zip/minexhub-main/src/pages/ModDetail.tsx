import Layout from "@/components/Layout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Download, Heart, Share2, Calendar, Package, ExternalLink, ThumbsUp, ThumbsDown, Eye, Copy, Check } from "lucide-react";
import { useParams } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import DOMPurify from 'dompurify';
import { ModpackInstaller } from "@/components/ModpackInstaller";
import { useState, useEffect } from "react";

export default function ModDetail() {
  const { slug } = useParams<{ slug: string }>();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [installerOpen, setInstallerOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const { data: mod, isLoading } = useQuery({
    queryKey: ['mod', slug],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('mods')
        .select(`
          *,
          mod_categories (
            categories (name, slug)
          ),
          mod_tags (
            tags (name)
          ),
          mod_images (url, title),
          mod_versions (
            *,
            version_loaders (loader),
            version_game_versions (
              minecraft_versions (version)
            )
          )
        `)
        .eq('slug', slug)
        .single();

      if (error) throw error;
      
      // Fetch author profile separately
      if (data && data.author_id) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('username, avatar_url')
          .eq('id', data.author_id)
          .single();
        
        return { ...data, author: profile };
      }
      
      return data;
    },
    enabled: !!slug
  });

  // Fetch user's reaction to this mod
  const { data: userReaction } = useQuery({
    queryKey: ['mod-reaction', mod?.id, user?.id],
    queryFn: async () => {
      if (!user?.id || !mod?.id) return null;
      const { data } = await supabase
        .from('mod_reactions')
        .select('*')
        .eq('mod_id', mod.id)
        .eq('user_id', user.id)
        .maybeSingle();
      return data;
    },
    enabled: !!user?.id && !!mod?.id,
  });

  // Fetch reaction counts
  const { data: reactionCounts } = useQuery({
    queryKey: ['mod-reaction-counts', mod?.id],
    queryFn: async () => {
      if (!mod?.id) return { likes: 0, dislikes: 0 };
      const { data } = await supabase
        .from('mod_reactions')
        .select('reaction_type')
        .eq('mod_id', mod.id);
      
      const likes = data?.filter(r => r.reaction_type === 'like').length || 0;
      const dislikes = data?.filter(r => r.reaction_type === 'dislike').length || 0;
      return { likes, dislikes };
    },
    enabled: !!mod?.id,
  });

  // Track page view
  useEffect(() => {
    if (mod?.id) {
      supabase
        .from('mods')
        .update({ views: ((mod as any).views || 0) + 1 })
        .eq('id', mod.id)
        .then();
    }
  }, [mod?.id]);

  // Handle reaction (like/dislike)
  const reactionMutation = useMutation({
    mutationFn: async (reactionType: 'like' | 'dislike') => {
      if (!user?.id || !mod?.id) throw new Error('Not authenticated');

      // If same reaction exists, remove it
      if (userReaction?.reaction_type === reactionType) {
        const { error } = await supabase
          .from('mod_reactions')
          .delete()
          .eq('mod_id', mod.id)
          .eq('user_id', user.id);
        if (error) throw error;
        return 'removed';
      }

      // Upsert the reaction
      const { error } = await supabase
        .from('mod_reactions')
        .upsert({
          mod_id: mod.id,
          user_id: user.id,
          reaction_type: reactionType,
        }, {
          onConflict: 'mod_id,user_id'
        });
      if (error) throw error;
      return reactionType;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mod-reaction', mod?.id, user?.id] });
      queryClient.invalidateQueries({ queryKey: ['mod-reaction-counts', mod?.id] });
    },
    onError: (error) => {
      toast.error('Failed to update reaction: ' + error.message);
    },
  });

  const handleReaction = (type: 'like' | 'dislike') => {
    if (!user) {
      toast.error('Please sign in to react');
      return;
    }
    reactionMutation.mutate(type);
  };

  const handleFavorite = async () => {
    if (!user) {
      toast.error("Please sign in to favorite mods");
      return;
    }

    const { error } = await supabase
      .from('user_favorites')
      .insert({ user_id: user.id, mod_id: mod?.id });

    if (error) {
      if (error.code === '23505') {
        toast.info("Already in favorites!");
      } else {
        toast.error("Failed to favorite mod");
      }
    } else {
      toast.success("Added to favorites!");
    }
  };

  const handleShare = async () => {
    const url = window.location.href;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: mod?.name,
          text: mod?.summary,
          url: url,
        });
      } catch (err) {
        // User cancelled or share failed, fall back to copy
        copyToClipboard(url);
      }
    } else {
      copyToClipboard(url);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    toast.success('Link copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = async (versionId: string, fileUrl: string, isExternal: boolean = false, externalUrl?: string) => {
    if (user) {
      await supabase.from('download_history').insert({
        user_id: user.id,
        mod_id: mod?.id,
        version_id: versionId
      });
    }

    // Use external URL for redirect, otherwise use hosted file URL
    const downloadUrl = isExternal && externalUrl ? externalUrl : fileUrl;
    window.open(downloadUrl, '_blank');
    
    await supabase
      .from('mods')
      .update({ downloads: (mod?.downloads || 0) + 1 })
      .eq('id', mod?.id);
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <Skeleton className="h-64 w-full mb-8" />
          <Skeleton className="h-8 w-3/4 mb-4" />
          <Skeleton className="h-4 w-full mb-2" />
          <Skeleton className="h-4 w-full" />
        </div>
      </Layout>
    );
  }

  if (!mod) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8 text-center">
          <h1 className="text-2xl font-bold">Mod not found</h1>
        </div>
      </Layout>
    );
  }

  const latestVersion = mod.mod_versions?.[0];

  return (
    <Layout>
      {/* Header Banner */}
      {mod.banner_url && (
        <div className="w-full h-64 overflow-hidden">
          <img src={mod.banner_url} alt={mod.name} className="w-full h-full object-cover" />
        </div>
      )}

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <div>
              <div className="flex items-start gap-4 mb-4">
                {mod.icon_url && (
                  <img src={mod.icon_url} alt={mod.name} className="w-20 h-20 rounded-lg" />
                )}
                <div className="flex-1">
                  <h1 className="text-4xl font-bold mb-2">{mod.name}</h1>
                  <p className="text-lg text-muted-foreground">{mod.summary}</p>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mb-4">
                <Badge>{mod.mod_type}</Badge>
                {mod.edition && <Badge variant="outline">{mod.edition}</Badge>}
                {mod.mod_categories?.map((mc: any) => (
                  <Badge key={mc.categories.slug} variant="secondary">
                    {mc.categories.name}
                  </Badge>
                ))}
                {mod.mod_tags?.map((mt: any) => (
                  <Badge key={mt.tags.name} variant="outline">
                    {mt.tags.name}
                  </Badge>
                ))}
              </div>

              <div className="flex flex-wrap gap-3 mb-6">
                {String(mod.mod_type) === 'modpack' ? (
                  <Button size="lg" onClick={() => setInstallerOpen(true)}>
                    <Package className="h-5 w-5 mr-2" />
                    Install Modpack
                  </Button>
                ) : (
                  <Button 
                    size="lg" 
                    onClick={() => latestVersion && handleDownload(
                      latestVersion.id, 
                      latestVersion.file_url,
                      latestVersion.is_external_link,
                      latestVersion.external_url
                    )}
                  >
                    {latestVersion?.is_external_link ? (
                      <>
                        <ExternalLink className="h-5 w-5 mr-2" />
                        Download (External)
                      </>
                    ) : (
                      <>
                        <Download className="h-5 w-5 mr-2" />
                        Download
                      </>
                    )}
                  </Button>
                )}
                
                {/* Like/Dislike Buttons */}
                <div className="flex items-center rounded-lg border border-border overflow-hidden">
                  <Button
                    variant={userReaction?.reaction_type === 'like' ? 'default' : 'ghost'}
                    size="lg"
                    className="rounded-none border-r border-border"
                    onClick={() => handleReaction('like')}
                    disabled={reactionMutation.isPending}
                  >
                    <ThumbsUp className={`h-5 w-5 mr-2 ${userReaction?.reaction_type === 'like' ? 'fill-current' : ''}`} />
                    {reactionCounts?.likes || 0}
                  </Button>
                  <Button
                    variant={userReaction?.reaction_type === 'dislike' ? 'destructive' : 'ghost'}
                    size="lg"
                    className="rounded-none"
                    onClick={() => handleReaction('dislike')}
                    disabled={reactionMutation.isPending}
                  >
                    <ThumbsDown className={`h-5 w-5 mr-2 ${userReaction?.reaction_type === 'dislike' ? 'fill-current' : ''}`} />
                    {reactionCounts?.dislikes || 0}
                  </Button>
                </div>

                <Button size="lg" variant="outline" onClick={handleFavorite}>
                  <Heart className="h-5 w-5 mr-2" />
                  Favorite
                </Button>
                <Button size="lg" variant="outline" onClick={handleShare}>
                  {copied ? <Check className="h-5 w-5 mr-2" /> : <Share2 className="h-5 w-5 mr-2" />}
                  {copied ? 'Copied!' : 'Share'}
                </Button>
              </div>
            </div>

            <Tabs defaultValue="description" className="w-full">
              <TabsList>
                <TabsTrigger value="description">Description</TabsTrigger>
                <TabsTrigger value="versions">Versions</TabsTrigger>
                <TabsTrigger value="gallery">Gallery</TabsTrigger>
              </TabsList>

              <TabsContent value="description" className="prose prose-neutral dark:prose-invert max-w-none">
                <div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(mod.description) }} />
              </TabsContent>

              <TabsContent value="versions">
                <div className="space-y-4">
                  {mod.mod_versions?.map((version: any) => (
                    <Card key={version.id} className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold text-lg">{version.version_number}</h3>
                          {version.name && <p className="text-sm text-muted-foreground">{version.name}</p>}
                          <div className="flex gap-2 mt-2">
                            {version.version_loaders?.map((vl: any) => (
                              <Badge key={vl.loader} variant="secondary">{vl.loader}</Badge>
                            ))}
                            {version.version_game_versions?.slice(0, 3).map((vg: any) => (
                              <Badge key={vg.minecraft_versions.version} variant="outline">
                                {vg.minecraft_versions.version}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <Button onClick={() => handleDownload(
                          version.id, 
                          version.file_url,
                          version.is_external_link,
                          version.external_url
                        )}>
                          {version.is_external_link ? (
                            <>
                              <ExternalLink className="h-4 w-4 mr-2" />
                              External
                            </>
                          ) : (
                            <>
                              <Download className="h-4 w-4 mr-2" />
                              Download
                            </>
                          )}
                        </Button>
                      </div>
                      {version.changelog && (
                        <div className="mt-3 pt-3 border-t">
                          <p className="text-sm">{version.changelog}</p>
                        </div>
                      )}
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="gallery">
                <div className="grid grid-cols-2 gap-4">
                  {mod.mod_images?.map((image: any) => (
                    <div key={image.url} className="aspect-video overflow-hidden rounded-lg">
                      <img src={image.url} alt={image.title} className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Compatibility Card */}
            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Compatibility</h3>
              <div className="space-y-4">
                {/* Loaders */}
                {(() => {
                  const allLoaders = mod.mod_versions?.flatMap((v: any) => 
                    v.version_loaders?.map((vl: any) => vl.loader) || []
                  ) || [];
                  const uniqueLoaders = Array.from(new Set(allLoaders));
                  
                  if (uniqueLoaders.length > 0) {
                    return (
                      <div>
                        <p className="text-sm text-muted-foreground mb-2">Loaders</p>
                        <div className="flex flex-wrap gap-2">
                          {uniqueLoaders.map((loader: string) => (
                            <Badge key={loader} className="capitalize bg-primary/10 text-primary border-primary/20">
                              {loader}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    );
                  }
                  return null;
                })()}

                {/* Minecraft Versions */}
                {(() => {
                  const allVersions = mod.mod_versions?.flatMap((v: any) => 
                    v.version_game_versions?.map((vg: any) => vg.minecraft_versions?.version) || []
                  ) || [];
                  const uniqueVersions = Array.from(new Set(allVersions.filter(Boolean)));
                  
                  if (uniqueVersions.length > 0) {
                    return (
                      <div>
                        <p className="text-sm text-muted-foreground mb-2">Minecraft Versions</p>
                        <div className="flex flex-wrap gap-2">
                          {uniqueVersions.slice(0, 10).map((version: string) => (
                            <Badge key={version} variant="outline" className="font-mono text-xs">
                              {version}
                            </Badge>
                          ))}
                          {uniqueVersions.length > 10 && (
                            <Badge variant="secondary" className="text-xs">
                              +{uniqueVersions.length - 10} more
                            </Badge>
                          )}
                        </div>
                      </div>
                    );
                  }
                  return null;
                })()}
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Information</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Downloads</span>
                  <span className="font-medium">{mod.downloads.toLocaleString()}</span>
                </div>
                <Separator />
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Views</span>
                  <span className="font-medium">{((mod as any).views || 0).toLocaleString()}</span>
                </div>
                <Separator />
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Likes</span>
                  <span className="font-medium text-green-500">{reactionCounts?.likes || 0}</span>
                </div>
                <Separator />
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Followers</span>
                  <span className="font-medium">{mod.followers.toLocaleString()}</span>
                </div>
                <Separator />
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Created</span>
                  <span className="font-medium">
                    {new Date(mod.created_at).toLocaleDateString()}
                  </span>
                </div>
                <Separator />
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Updated</span>
                  <span className="font-medium">
                    {new Date(mod.updated_at).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Author</h3>
              <div className="flex items-center gap-3">
                {(mod as any).author?.avatar_url && (
                  <img src={(mod as any).author.avatar_url} alt={(mod as any).author.username} className="w-12 h-12 rounded-full" />
                )}
                <div>
                  <p className="font-medium">{(mod as any).author?.username || 'Unknown'}</p>
                </div>
              </div>
            </Card>

            {(mod.source_url || mod.issues_url || mod.wiki_url || mod.discord_url) && (
              <Card className="p-6">
                <h3 className="font-semibold text-lg mb-4">External Links</h3>
                <div className="space-y-2">
                  {mod.source_url && (
                    <a href={mod.source_url} target="_blank" rel="noopener noreferrer" className="block text-primary hover:underline">
                      Source Code
                    </a>
                  )}
                  {mod.issues_url && (
                    <a href={mod.issues_url} target="_blank" rel="noopener noreferrer" className="block text-primary hover:underline">
                      Issue Tracker
                    </a>
                  )}
                  {mod.wiki_url && (
                    <a href={mod.wiki_url} target="_blank" rel="noopener noreferrer" className="block text-primary hover:underline">
                      Wiki
                    </a>
                  )}
                  {mod.discord_url && (
                    <a href={mod.discord_url} target="_blank" rel="noopener noreferrer" className="block text-primary hover:underline">
                      Discord
                    </a>
                  )}
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>

      <ModpackInstaller
        modpackId={mod.id}
        modpackName={mod.name}
        open={installerOpen}
        onOpenChange={setInstallerOpen}
      />
    </Layout>
  );
}