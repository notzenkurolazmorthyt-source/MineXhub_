import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useParams } from "react-router-dom";
import { Download, Star, Heart, Flag, Calendar, User, Package } from "lucide-react";
import { useState } from "react";

export default function ContentDetail() {
  const { id } = useParams();
  const [selectedGameVersion, setSelectedGameVersion] = useState("1.20.1");
  const [selectedLoader, setSelectedLoader] = useState("all");

  // Mock data - in real app would fetch based on id
  const content = {
    title: "OptiFine HD Ultra",
    type: "Mod",
    edition: "Java",
    author: "sp614x",
    downloads: "50M+",
    rating: 4.9,
    ratingCount: "125K",
    image: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&h=400&fit=crop",
    description: "OptiFine is a Minecraft optimization mod that boosts FPS, supports HD textures and shaders, and adds many visual quality options.",
    longDescription: `OptiFine is a Minecraft optimization mod that significantly improves game performance and visual quality. It includes FPS boost, HD texture support, shader support, and numerous visual enhancements.

Key Features:
• FPS boost through various performance optimizations
• Support for HD textures and customization
• Shader support for advanced graphics
• Dynamic lighting and smooth lighting improvements
• Better grass and snow rendering
• Customizable animations and particles
• Zoom functionality
• And many more visual improvements`,
    tags: ["Performance", "Graphics", "Optimization", "Shaders"],
    versions: [
      { 
        id: "v1",
        gameVersion: "1.20.1", 
        modVersion: "HD_U_I5",
        loader: "Forge", 
        date: "2024-01-15", 
        downloads: "5M",
        downloadUrl: "#forge-1.20.1"
      },
      { 
        id: "v2",
        gameVersion: "1.20.1", 
        modVersion: "HD_U_I5",
        loader: "Fabric", 
        date: "2024-01-15", 
        downloads: "3M",
        downloadUrl: "#fabric-1.20.1"
      },
      { 
        id: "v3",
        gameVersion: "1.19.4", 
        modVersion: "HD_U_I4",
        loader: "Forge", 
        date: "2023-12-10", 
        downloads: "8M",
        downloadUrl: "#forge-1.19.4"
      },
      { 
        id: "v4",
        gameVersion: "1.19.4", 
        modVersion: "HD_U_I4",
        loader: "Fabric", 
        date: "2023-12-10", 
        downloads: "5M",
        downloadUrl: "#fabric-1.19.4"
      },
      { 
        id: "v5",
        gameVersion: "1.18.2", 
        modVersion: "HD_U_I3",
        loader: "Forge", 
        date: "2023-10-05", 
        downloads: "12M",
        downloadUrl: "#forge-1.18.2"
      },
    ],
    changelog: `Version 1.20.1 - January 15, 2024

New Features:
• Added support for Minecraft 1.20.1
• Improved shader compatibility
• Enhanced performance optimizations

Bug Fixes:
• Fixed crash with certain texture packs
• Resolved memory leak issues
• Fixed rendering glitches with certain blocks`,
    images: [
      "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=400&h=300&fit=crop",
      "https://images.unsplash.com/photo-1614732414444-096e5f1122d5?w=400&h=300&fit=crop",
      "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400&h=300&fit=crop",
    ],
  };

  const availableGameVersions = [...new Set(content.versions.map(v => v.gameVersion))];
  const availableLoaders = ["all", ...new Set(content.versions.map(v => v.loader))];
  
  const filteredVersions = content.versions.filter(v => {
    const matchesGameVersion = selectedGameVersion === "all" || v.gameVersion === selectedGameVersion;
    const matchesLoader = selectedLoader === "all" || v.loader === selectedLoader;
    return matchesGameVersion && matchesLoader;
  });

  const currentVersion = filteredVersions[0];

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          <div className="lg:col-span-2 space-y-6">
            <div className="aspect-video w-full overflow-hidden rounded-lg bg-muted">
              <img
                src={content.image}
                alt={content.title}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="flex flex-wrap gap-2">
              {content.images.map((img, i) => (
                <div key={i} className="w-32 h-24 rounded-lg overflow-hidden bg-muted cursor-pointer hover:opacity-80 transition">
                  <img src={img} alt={`Screenshot ${i + 1}`} className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <Card className="p-6 space-y-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="secondary">{content.type}</Badge>
                  <Badge variant="outline">{content.edition}</Badge>
                </div>
                <h1 className="text-3xl font-bold mb-2">{content.title}</h1>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <User className="h-4 w-4" />
                  <span>by {content.author}</span>
                </div>
              </div>

              <Separator />

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Downloads</span>
                  <div className="flex items-center gap-1">
                    <Download className="h-4 w-4" />
                    <span className="font-semibold">{content.downloads}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Rating</span>
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-minecraft-gold text-minecraft-gold" />
                    <span className="font-semibold">{content.rating}</span>
                    <span className="text-sm text-muted-foreground">({content.ratingCount})</span>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-3">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Game Version</label>
                  <Select value={selectedGameVersion} onValueChange={setSelectedGameVersion}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {availableGameVersions.map((version) => (
                        <SelectItem key={version} value={version}>
                          {version}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Mod Loader</label>
                  <Select value={selectedLoader} onValueChange={setSelectedLoader}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {availableLoaders.map((loader) => (
                        <SelectItem key={loader} value={loader}>
                          {loader === "all" ? "All Loaders" : loader}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {currentVersion && (
                  <div className="p-3 bg-muted/50 rounded-lg space-y-1">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="bg-primary/10">
                        {currentVersion.loader}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        v{currentVersion.modVersion}
                      </span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {currentVersion.downloads} downloads • {currentVersion.date}
                    </div>
                  </div>
                )}
              </div>

              <Button className="w-full" size="lg" asChild>
                <a href={currentVersion?.downloadUrl || "#"} download>
                  <Download className="h-5 w-5 mr-2" />
                  Download {currentVersion?.loader || ""}
                </a>
              </Button>

              <div className="flex gap-2">
                <Button variant="outline" className="flex-1">
                  <Heart className="h-4 w-4 mr-2" />
                  Save
                </Button>
                <Button variant="outline" className="flex-1">
                  <Flag className="h-4 w-4 mr-2" />
                  Report
                </Button>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold mb-4">Tags</h3>
              <div className="flex flex-wrap gap-2">
                {content.tags.map((tag) => (
                  <Badge key={tag} variant="outline">
                    {tag}
                  </Badge>
                ))}
              </div>
            </Card>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="description" className="mb-8">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="description">Description</TabsTrigger>
            <TabsTrigger value="versions">Versions</TabsTrigger>
            <TabsTrigger value="changelog">Changelog</TabsTrigger>
          </TabsList>

          <TabsContent value="description" className="mt-6">
            <Card className="p-6">
              <p className="text-muted-foreground whitespace-pre-line">
                {content.longDescription}
              </p>
            </Card>
          </TabsContent>

          <TabsContent value="versions" className="mt-6">
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">All Versions</h3>
                <div className="flex gap-2">
                  <Select value={selectedGameVersion} onValueChange={setSelectedGameVersion}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Versions</SelectItem>
                      {availableGameVersions.map((version) => (
                        <SelectItem key={version} value={version}>
                          {version}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={selectedLoader} onValueChange={setSelectedLoader}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {availableLoaders.map((loader) => (
                        <SelectItem key={loader} value={loader}>
                          {loader === "all" ? "All Loaders" : loader}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-3">
                {filteredVersions.map((version) => (
                  <div
                    key={version.id}
                    className="flex items-center justify-between p-4 rounded-lg border border-border hover:bg-muted/50 transition"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <Package className="h-4 w-4 text-primary" />
                        <span className="font-semibold">
                          {version.gameVersion} - v{version.modVersion}
                        </span>
                        <Badge variant="outline" className="bg-primary/10">
                          {version.loader}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="h-3 w-3" />
                        <span>{version.date}</span>
                        <span>•</span>
                        <Download className="h-3 w-3" />
                        <span>{version.downloads} downloads</span>
                      </div>
                    </div>
                    <Button asChild>
                      <a href={version.downloadUrl} download>
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </a>
                    </Button>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="changelog" className="mt-6">
            <Card className="p-6">
              <pre className="text-sm text-muted-foreground whitespace-pre-line font-sans">
                {content.changelog}
              </pre>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
