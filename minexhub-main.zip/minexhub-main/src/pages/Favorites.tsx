import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '@/components/Layout';
import { useAuth } from '@/hooks/useAuth';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { ModCard } from '@/components/ModCard';
import { Skeleton } from '@/components/ui/skeleton';
import { Heart } from 'lucide-react';

export default function Favorites() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  const { data: favorites, isLoading } = useQuery({
    queryKey: ['favorites', user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from('user_favorites')
        .select(`
          created_at,
          mods (
            id,
            slug,
            name,
            summary,
            icon_url,
            downloads,
            mod_type,
            featured
          )
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    },
    enabled: !!user
  });

  if (loading || !user) {
    return (
      <Layout>
        <div className="container mx-auto py-8 px-4">
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto py-8 px-4">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Heart className="h-8 w-8 text-primary" />
            <h1 className="text-4xl font-bold">Your Favorites</h1>
          </div>
          <p className="text-muted-foreground">
            {favorites?.length || 0} saved items
          </p>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <Skeleton key={i} className="h-64" />
            ))}
          </div>
        ) : favorites && favorites.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {favorites.map((fav: any) => (
              <ModCard
                key={fav.mods.id}
                id={fav.mods.id}
                slug={fav.mods.slug}
                name={fav.mods.name}
                summary={fav.mods.summary}
                iconUrl={fav.mods.icon_url || undefined}
                downloads={fav.mods.downloads}
                modType={fav.mods.mod_type}
                featured={fav.mods.featured}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Heart className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground text-lg">No favorites yet</p>
            <p className="text-sm text-muted-foreground mt-2">
              Start exploring and add your favorite mods!
            </p>
          </div>
        )}
      </div>
    </Layout>
  );
}
