import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Link, Navigate } from "react-router-dom";
import { Settings, Upload, Download, Star, Heart, Calendar, Edit, Camera, Loader2, Eye, ThumbsUp } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

export default function Profile() {
  const { user, loading } = useAuth();
  const queryClient = useQueryClient();
  const [editOpen, setEditOpen] = useState(false);
  const [editData, setEditData] = useState({ username: '', display_name: '', bio: '', avatar_url: '' });
  const [uploading, setUploading] = useState(false);

  // Fetch profile data
  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: ['profile', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  // Fetch user's uploaded mods
  const { data: uploads = [] } = useQuery({
    queryKey: ['user-uploads', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      const { data, error } = await supabase
        .from('mods')
        .select('*')
        .eq('author_id', user.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  // Fetch user's favorites
  const { data: favorites = [] } = useQuery({
    queryKey: ['user-favorites', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      const { data, error } = await supabase
        .from('user_favorites')
        .select('*, mods(*)')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  // Fetch download history
  const { data: downloads = [] } = useQuery({
    queryKey: ['user-downloads', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      const { data, error } = await supabase
        .from('download_history')
        .select('*, mods(*)')
        .eq('user_id', user.id)
        .order('downloaded_at', { ascending: false })
        .limit(20);
      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  // Update profile mutation - use upsert to handle missing profiles
  const updateProfile = useMutation({
    mutationFn: async (data: { username: string; display_name: string; bio: string; avatar_url: string }) => {
      if (!user?.id) throw new Error('Not authenticated');
      const { error } = await supabase
        .from('profiles')
        .upsert({
          id: user.id,
          ...data,
          updated_at: new Date().toISOString(),
        });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['profile', user?.id] });
      toast.success('Profile updated successfully!');
      setEditOpen(false);
    },
    onError: (error) => {
      toast.error('Failed to update profile: ' + error.message);
    },
  });

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user?.id) return;

    setUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}/avatar.${fileExt}`;
      
      const { error: uploadError } = await supabase.storage
        .from('mod-images')
        .upload(fileName, file, { upsert: true });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('mod-images')
        .getPublicUrl(fileName);

      setEditData(prev => ({ ...prev, avatar_url: publicUrl }));
      toast.success('Avatar uploaded!');
    } catch (error: any) {
      toast.error('Upload failed: ' + error.message);
    } finally {
      setUploading(false);
    }
  };

  const openEditDialog = () => {
    setEditData({
      username: profile?.username || '',
      display_name: profile?.display_name || '',
      bio: profile?.bio || '',
      avatar_url: profile?.avatar_url || '',
    });
    setEditOpen(true);
  };

  // Calculate stats
  const totalDownloads = uploads.reduce((sum, mod) => sum + (mod.downloads || 0), 0);
  const totalLikes = uploads.reduce((sum, mod) => sum + ((mod as any).likes || 0), 0);
  const totalViews = uploads.reduce((sum, mod) => sum + ((mod as any).views || 0), 0);

  if (loading || profileLoading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-16 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Profile Header */}
        <Card className="p-6 mb-8">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
            <Avatar className="h-24 w-24">
              <AvatarImage src={profile?.avatar_url || ''} alt={profile?.display_name || 'User'} />
              <AvatarFallback className="text-2xl">
                {profile?.display_name?.[0] || user.email?.[0]?.toUpperCase()}
              </AvatarFallback>
            </Avatar>

            <div className="flex-1">
              <div className="flex items-start justify-between gap-4 mb-2">
                <div>
                  <h1 className="text-3xl font-bold">{profile?.display_name || 'User'}</h1>
                  <p className="text-muted-foreground">@{profile?.username || 'user'}</p>
                  {profile?.bio && (
                    <p className="text-sm text-muted-foreground mt-2">{profile.bio}</p>
                  )}
                </div>
                <Dialog open={editOpen} onOpenChange={setEditOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="icon" onClick={openEditDialog}>
                      <Edit className="h-5 w-5" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Edit Profile</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="flex flex-col items-center gap-4">
                        <Avatar className="h-20 w-20">
                          <AvatarImage src={editData.avatar_url} />
                          <AvatarFallback>{editData.display_name?.[0] || 'U'}</AvatarFallback>
                        </Avatar>
                        <Label htmlFor="avatar" className="cursor-pointer">
                          <div className="flex items-center gap-2 text-sm text-primary hover:underline">
                            <Camera className="h-4 w-4" />
                            {uploading ? 'Uploading...' : 'Change Avatar'}
                          </div>
                          <Input
                            id="avatar"
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={handleAvatarUpload}
                            disabled={uploading}
                          />
                        </Label>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="username">Username</Label>
                        <Input
                          id="username"
                          value={editData.username}
                          onChange={(e) => setEditData(prev => ({ ...prev, username: e.target.value }))}
                          placeholder="Your username"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="display_name">Display Name</Label>
                        <Input
                          id="display_name"
                          value={editData.display_name}
                          onChange={(e) => setEditData(prev => ({ ...prev, display_name: e.target.value }))}
                          placeholder="Your display name"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="bio">Bio</Label>
                        <Textarea
                          id="bio"
                          value={editData.bio}
                          onChange={(e) => setEditData(prev => ({ ...prev, bio: e.target.value }))}
                          placeholder="Tell us about yourself..."
                          rows={3}
                        />
                      </div>
                      <Button
                        className="w-full"
                        onClick={() => updateProfile.mutate(editData)}
                        disabled={updateProfile.isPending}
                      >
                        {updateProfile.isPending ? 'Saving...' : 'Save Changes'}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                <div className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  Joined {profile?.created_at ? new Date(profile.created_at).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) : 'Recently'}
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="text-center p-3 rounded-lg bg-muted/50">
                  <div className="text-2xl font-bold text-primary">{uploads.length}</div>
                  <div className="text-sm text-muted-foreground">Uploads</div>
                </div>
                <div className="text-center p-3 rounded-lg bg-muted/50">
                  <div className="text-2xl font-bold text-accent">{totalDownloads.toLocaleString()}</div>
                  <div className="text-sm text-muted-foreground">Downloads</div>
                </div>
                <div className="text-center p-3 rounded-lg bg-muted/50">
                  <div className="text-2xl font-bold text-minecraft-gold">{totalViews.toLocaleString()}</div>
                  <div className="text-sm text-muted-foreground">Views</div>
                </div>
                <div className="text-center p-3 rounded-lg bg-muted/50">
                  <div className="text-2xl font-bold text-green-500">{totalLikes.toLocaleString()}</div>
                  <div className="text-sm text-muted-foreground">Likes</div>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Content Tabs */}
        <Tabs defaultValue="uploads" className="mb-8">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="uploads">My Uploads ({uploads.length})</TabsTrigger>
            <TabsTrigger value="saved">Saved ({favorites.length})</TabsTrigger>
            <TabsTrigger value="downloads">Download History ({downloads.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="uploads" className="mt-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-semibold">My Uploads</h2>
              <Button asChild>
                <Link to="/upload">
                  <Upload className="h-4 w-4 mr-2" />
                  Upload New Content
                </Link>
              </Button>
            </div>

            {uploads.length === 0 ? (
              <Card className="p-8 text-center">
                <Upload className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No uploads yet</h3>
                <p className="text-muted-foreground mb-4">Share your creations with the community!</p>
                <Button asChild>
                  <Link to="/upload">Upload Your First Mod</Link>
                </Button>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {uploads.map((item) => (
                  <Link key={item.id} to={`/mod/${item.slug}`}>
                    <Card className="overflow-hidden hover:shadow-xl transition-all hover:scale-[1.02] cursor-pointer">
                      <div className="aspect-video w-full overflow-hidden bg-muted">
                        <img
                          src={item.icon_url || '/placeholder.svg'}
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="p-4 space-y-3">
                        <div className="flex items-start justify-between gap-2">
                          <h3 className="font-semibold line-clamp-1">{item.name}</h3>
                          <Badge variant={item.status === 'approved' ? 'default' : 'secondary'} className="shrink-0">
                            {item.status}
                          </Badge>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <div className="flex items-center gap-3 text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Download className="h-4 w-4" />
                              {item.downloads.toLocaleString()}
                            </span>
                            <span className="flex items-center gap-1">
                              <Eye className="h-4 w-4" />
                              {((item as any).views || 0).toLocaleString()}
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <ThumbsUp className="h-4 w-4 text-green-500" />
                            {((item as any).likes || 0).toLocaleString()}
                          </div>
                        </div>
                      </div>
                    </Card>
                  </Link>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="saved" className="mt-6">
            <div className="mb-6">
              <h2 className="text-2xl font-semibold">Saved Content</h2>
              <p className="text-muted-foreground">Content you've favorited</p>
            </div>

            {favorites.length === 0 ? (
              <Card className="p-8 text-center">
                <Heart className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No saved content</h3>
                <p className="text-muted-foreground mb-4">Explore and save your favorite mods!</p>
                <Button asChild variant="outline">
                  <Link to="/explore">Explore Mods</Link>
                </Button>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {favorites.map((item) => (
                  <Link key={item.id} to={`/mod/${item.mods?.slug}`}>
                    <Card className="overflow-hidden hover:shadow-xl transition-all hover:scale-[1.02] cursor-pointer">
                      <div className="aspect-video w-full overflow-hidden bg-muted">
                        <img
                          src={item.mods?.icon_url || '/placeholder.svg'}
                          alt={item.mods?.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="p-4 space-y-3">
                        <div className="flex items-start justify-between gap-2">
                          <h3 className="font-semibold line-clamp-1">{item.mods?.name}</h3>
                          <Badge variant="secondary" className="shrink-0">
                            {item.mods?.mod_type}
                          </Badge>
                        </div>
                        <Button variant="outline" size="sm" className="w-full">
                          <Heart className="h-4 w-4 mr-2 fill-red-500 text-red-500" />
                          Saved
                        </Button>
                      </div>
                    </Card>
                  </Link>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="downloads" className="mt-6">
            <div className="mb-6">
              <h2 className="text-2xl font-semibold">Download History</h2>
              <p className="text-muted-foreground">Your recent downloads</p>
            </div>

            {downloads.length === 0 ? (
              <Card className="p-8 text-center">
                <Download className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No downloads yet</h3>
                <p className="text-muted-foreground mb-4">Start downloading mods to see your history here!</p>
                <Button asChild variant="outline">
                  <Link to="/explore">Browse Mods</Link>
                </Button>
              </Card>
            ) : (
              <Card className="p-6">
                <div className="space-y-4">
                  {downloads.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center justify-between p-4 rounded-lg border border-border hover:bg-muted/50 transition"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 rounded-lg overflow-hidden bg-muted">
                          <img
                            src={item.mods?.icon_url || '/placeholder.svg'}
                            alt={item.mods?.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <h3 className="font-semibold">{item.mods?.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            Downloaded {new Date(item.downloaded_at).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm" asChild>
                        <Link to={`/mod/${item.mods?.slug}`}>View</Link>
                      </Button>
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}