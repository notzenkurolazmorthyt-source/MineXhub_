import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import Layout from '@/components/Layout';
import { RefreshCw, CheckCircle, AlertCircle, Users, Package, Shield, BarChart3, Search, Check, X, Eye, ChevronLeft, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import type { Database } from '@/integrations/supabase/types';

export default function Admin() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [syncing, setSyncing] = useState(false);
  const [syncResult, setSyncResult] = useState<any>(null);
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [userSearch, setUserSearch] = useState('');
  const [modSearch, setModSearch] = useState('');
  const [modPage, setModPage] = useState(1);
  const [userPage, setUserPage] = useState(1);
  const ITEMS_PER_PAGE = 10;

  useEffect(() => {
    const checkAdminRole = async () => {
      if (!user) {
        navigate('/auth');
        return;
      }

      const { data, error } = await supabase.rpc('has_role', {
        _user_id: user.id,
        _role: 'admin'
      });

      if (error || !data) {
        toast.error('Access denied', {
          description: 'You do not have admin permissions'
        });
        navigate('/');
        return;
      }

      setIsAdmin(true);
    };

    if (!loading) {
      checkAdminRole();
    }
  }, [user, loading, navigate]);

  // Fetch stats
  const { data: stats } = useQuery({
    queryKey: ['admin-stats'],
    queryFn: async () => {
      const [modsResult, usersResult, pendingResult, downloadsResult] = await Promise.all([
        supabase.from('mods').select('id', { count: 'exact', head: true }),
        supabase.from('profiles').select('id', { count: 'exact', head: true }),
        supabase.from('mods').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
        supabase.from('mods').select('downloads').then(res => 
          res.data?.reduce((acc, m) => acc + (m.downloads || 0), 0) || 0
        )
      ]);
      
      return {
        totalMods: modsResult.count || 0,
        totalUsers: usersResult.count || 0,
        pendingMods: pendingResult.count || 0,
        totalDownloads: downloadsResult
      };
    },
    enabled: isAdmin === true
  });

  // Fetch pending mods with pagination
  const { data: modsData, isLoading: loadingMods } = useQuery({
    queryKey: ['pending-mods', modSearch, modPage],
    queryFn: async () => {
      const from = (modPage - 1) * ITEMS_PER_PAGE;
      const to = from + ITEMS_PER_PAGE - 1;
      
      let query = supabase
        .from('mods')
        .select('id, name, slug, summary, mod_type, created_at, status, icon_url', { count: 'exact' })
        .in('status', ['pending', 'draft'])
        .order('created_at', { ascending: false });
      
      if (modSearch) {
        query = query.ilike('name', `%${modSearch}%`);
      }
      
      const { data, error, count } = await query.range(from, to);
      if (error) throw error;
      return { mods: data, total: count || 0 };
    },
    enabled: isAdmin === true
  });

  const pendingMods = modsData?.mods;
  const totalMods = modsData?.total || 0;
  const totalModPages = Math.ceil(totalMods / ITEMS_PER_PAGE);

  // Fetch users with roles and pagination
  const { data: usersData, isLoading: loadingUsers } = useQuery({
    queryKey: ['admin-users', userSearch, userPage],
    queryFn: async () => {
      const from = (userPage - 1) * ITEMS_PER_PAGE;
      const to = from + ITEMS_PER_PAGE - 1;
      
      let query = supabase
        .from('profiles')
        .select('id, username, display_name, avatar_url, created_at', { count: 'exact' })
        .order('created_at', { ascending: false });
      
      if (userSearch) {
        query = query.ilike('username', `%${userSearch}%`);
      }
      
      const { data: profiles, error, count } = await query.range(from, to);
      if (error) throw error;

      // Get roles for these users
      const { data: roles } = await supabase
        .from('user_roles')
        .select('user_id, role')
        .in('user_id', profiles?.map(p => p.id) || []);

      const usersWithRoles = profiles?.map(p => ({
        ...p,
        roles: roles?.filter(r => r.user_id === p.id).map(r => r.role) || []
      }));

      return { users: usersWithRoles, total: count || 0 };
    },
    enabled: isAdmin === true
  });

  const users = usersData?.users;
  const totalUsers = usersData?.total || 0;
  const totalUserPages = Math.ceil(totalUsers / ITEMS_PER_PAGE);

  // Mutation for updating mod status
  const updateModStatus = useMutation({
    mutationFn: async ({ modId, status }: { modId: string; status: Database['public']['Enums']['mod_status'] }) => {
      const { error } = await supabase
        .from('mods')
        .update({ status })
        .eq('id', modId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pending-mods'] });
      queryClient.invalidateQueries({ queryKey: ['admin-stats'] });
      toast.success('Mod status updated');
    },
    onError: (error: any) => {
      toast.error('Failed to update mod status', { description: error.message });
    }
  });

  // Mutation for adding/removing roles
  const updateUserRole = useMutation({
    mutationFn: async ({ userId, role, action }: { userId: string; role: Database['public']['Enums']['app_role']; action: 'add' | 'remove' }) => {
      if (action === 'add') {
        const { error } = await supabase
          .from('user_roles')
          .insert({ user_id: userId, role });
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('user_roles')
          .delete()
          .eq('user_id', userId)
          .eq('role', role);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-users'] });
      toast.success('User role updated');
    },
    onError: (error: any) => {
      toast.error('Failed to update user role', { description: error.message });
    }
  });

  const handleSync = async () => {
    setSyncing(true);
    setSyncResult(null);
    
    try {
      toast.info('Starting Modrinth sync...', {
        description: 'This will fetch 100 popular items from each category'
      });

      const { data, error } = await supabase.functions.invoke('sync-modrinth', {
        body: {}
      });

      if (error) throw error;

      setSyncResult(data);
      queryClient.invalidateQueries({ queryKey: ['admin-stats'] });
      toast.success('Sync completed successfully!', {
        description: `Synced ${data.totalSynced} projects`
      });
    } catch (error: any) {
      console.error('Sync error:', error);
      toast.error('Sync failed', {
        description: error.message || 'Unknown error occurred'
      });
      setSyncResult({ error: error.message });
    } finally {
      setSyncing(false);
    }
  };

  if (loading || isAdmin === null) {
    return (
      <Layout>
        <div className="container mx-auto py-8 px-4">
          <div className="max-w-6xl mx-auto">
            <p className="text-muted-foreground">Loading...</p>
          </div>
        </div>
      </Layout>
    );
  }

  if (!isAdmin) {
    return null;
  }

  return (
    <Layout>
      <div className="container mx-auto py-8 px-4">
        <div className="max-w-6xl mx-auto space-y-6">
          <div>
            <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
            <p className="text-muted-foreground">
              Manage users, content, and platform settings
            </p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <Package className="h-8 w-8 text-primary" />
                  <div>
                    <p className="text-2xl font-bold">{stats?.totalMods || 0}</p>
                    <p className="text-sm text-muted-foreground">Total Content</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <Users className="h-8 w-8 text-primary" />
                  <div>
                    <p className="text-2xl font-bold">{stats?.totalUsers || 0}</p>
                    <p className="text-sm text-muted-foreground">Users</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <AlertCircle className="h-8 w-8 text-warning" />
                  <div>
                    <p className="text-2xl font-bold">{stats?.pendingMods || 0}</p>
                    <p className="text-sm text-muted-foreground">Pending Review</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <BarChart3 className="h-8 w-8 text-primary" />
                  <div>
                    <p className="text-2xl font-bold">{(stats?.totalDownloads || 0).toLocaleString()}</p>
                    <p className="text-sm text-muted-foreground">Downloads</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="moderation" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="moderation" className="flex items-center gap-2">
                <Shield className="h-4 w-4" />
                Content Moderation
              </TabsTrigger>
              <TabsTrigger value="users" className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                Users
              </TabsTrigger>
              <TabsTrigger value="sync" className="flex items-center gap-2">
                <RefreshCw className="h-4 w-4" />
                Sync
              </TabsTrigger>
            </TabsList>

            {/* Content Moderation Tab */}
            <TabsContent value="moderation" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Pending Content</CardTitle>
                  <CardDescription>Review and approve user-submitted content</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search content..."
                        value={modSearch}
                        onChange={(e) => { setModSearch(e.target.value); setModPage(1); }}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  
                  {loadingMods ? (
                    <p className="text-muted-foreground">Loading...</p>
                  ) : pendingMods?.length === 0 ? (
                    <p className="text-muted-foreground text-center py-8">No pending content to review</p>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Content</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Created</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {pendingMods?.map((mod) => (
                          <TableRow key={mod.id}>
                            <TableCell>
                              <div className="flex items-center gap-3">
                                {mod.icon_url && (
                                  <img src={mod.icon_url} alt="" className="w-10 h-10 rounded" />
                                )}
                                <div>
                                  <p className="font-medium">{mod.name}</p>
                                  <p className="text-sm text-muted-foreground line-clamp-1">{mod.summary}</p>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="capitalize">{mod.mod_type}</Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant={mod.status === 'pending' ? 'secondary' : 'outline'}>
                                {mod.status}
                              </Badge>
                            </TableCell>
                            <TableCell>{new Date(mod.created_at).toLocaleDateString()}</TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  asChild
                                >
                                  <Link to={`/mod/${mod.slug}`}>
                                    <Eye className="h-4 w-4" />
                                  </Link>
                                </Button>
                                <Button
                                  size="sm"
                                  variant="default"
                                  onClick={() => updateModStatus.mutate({ modId: mod.id, status: 'approved' })}
                                  disabled={updateModStatus.isPending}
                                >
                                  <Check className="h-4 w-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => updateModStatus.mutate({ modId: mod.id, status: 'rejected' })}
                                  disabled={updateModStatus.isPending}
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                  
                  {/* Pagination */}
                  {totalModPages > 1 && (
                    <div className="flex items-center justify-between pt-4">
                      <p className="text-sm text-muted-foreground">
                        Showing {((modPage - 1) * ITEMS_PER_PAGE) + 1}-{Math.min(modPage * ITEMS_PER_PAGE, totalMods)} of {totalMods}
                      </p>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setModPage(p => Math.max(1, p - 1))}
                          disabled={modPage === 1}
                        >
                          <ChevronLeft className="h-4 w-4" />
                        </Button>
                        <span className="text-sm">Page {modPage} of {totalModPages}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setModPage(p => Math.min(totalModPages, p + 1))}
                          disabled={modPage === totalModPages}
                        >
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Users Tab */}
            <TabsContent value="users" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>User Management</CardTitle>
                  <CardDescription>Manage user roles and permissions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search users..."
                        value={userSearch}
                        onChange={(e) => { setUserSearch(e.target.value); setUserPage(1); }}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  
                  {loadingUsers ? (
                    <p className="text-muted-foreground">Loading...</p>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>User</TableHead>
                          <TableHead>Roles</TableHead>
                          <TableHead>Joined</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {users?.map((u) => (
                          <TableRow key={u.id}>
                            <TableCell>
                              <div className="flex items-center gap-3">
                                {u.avatar_url ? (
                                  <img src={u.avatar_url} alt="" className="w-8 h-8 rounded-full" />
                                ) : (
                                  <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                                    <Users className="h-4 w-4" />
                                  </div>
                                )}
                                <div>
                                  <p className="font-medium">{u.display_name || u.username}</p>
                                  <p className="text-sm text-muted-foreground">@{u.username}</p>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-1">
                                {u.roles.length === 0 ? (
                                  <Badge variant="outline">user</Badge>
                                ) : (
                                  u.roles.map((role: string) => (
                                    <Badge key={role} variant={role === 'admin' ? 'destructive' : 'secondary'}>
                                      {role}
                                    </Badge>
                                  ))
                                )}
                              </div>
                            </TableCell>
                            <TableCell>{new Date(u.created_at).toLocaleDateString()}</TableCell>
                            <TableCell className="text-right">
                              <Select
                                onValueChange={(value) => {
                                  const [action, role] = value.split(':');
                                  updateUserRole.mutate({ 
                                    userId: u.id, 
                                    role: role as Database['public']['Enums']['app_role'], 
                                    action: action as 'add' | 'remove' 
                                  });
                                }}
                              >
                                <SelectTrigger className="w-32">
                                  <SelectValue placeholder="Manage" />
                                </SelectTrigger>
                                <SelectContent>
                                  {!u.roles.includes('moderator') && (
                                    <SelectItem value="add:moderator">Add Moderator</SelectItem>
                                  )}
                                  {u.roles.includes('moderator') && (
                                    <SelectItem value="remove:moderator">Remove Moderator</SelectItem>
                                  )}
                                  {!u.roles.includes('admin') && u.id !== user?.id && (
                                    <SelectItem value="add:admin">Add Admin</SelectItem>
                                  )}
                                  {u.roles.includes('admin') && u.id !== user?.id && (
                                    <SelectItem value="remove:admin">Remove Admin</SelectItem>
                                  )}
                                </SelectContent>
                              </Select>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                  
                  {/* Pagination */}
                  {totalUserPages > 1 && (
                    <div className="flex items-center justify-between pt-4">
                      <p className="text-sm text-muted-foreground">
                        Showing {((userPage - 1) * ITEMS_PER_PAGE) + 1}-{Math.min(userPage * ITEMS_PER_PAGE, totalUsers)} of {totalUsers}
                      </p>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setUserPage(p => Math.max(1, p - 1))}
                          disabled={userPage === 1}
                        >
                          <ChevronLeft className="h-4 w-4" />
                        </Button>
                        <span className="text-sm">Page {userPage} of {totalUserPages}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setUserPage(p => Math.min(totalUserPages, p + 1))}
                          disabled={userPage === totalUserPages}
                        >
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="sync" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Modrinth Sync</CardTitle>
                  <CardDescription>
                    Fetch and sync the latest popular content from Modrinth including mods, shaders, 
                    resource packs, plugins, modpacks, and datapacks
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button 
                    onClick={handleSync} 
                    disabled={syncing}
                    size="lg"
                    className="w-full sm:w-auto"
                  >
                    {syncing ? (
                      <>
                        <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                        Syncing...
                      </>
                    ) : (
                      <>
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Start Sync
                      </>
                    )}
                  </Button>

                  {syncResult && (
                    <Card className={syncResult.error ? 'border-destructive' : 'border-primary'}>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          {syncResult.error ? (
                            <>
                              <AlertCircle className="h-5 w-5 text-destructive" />
                              Sync Failed
                            </>
                          ) : (
                            <>
                              <CheckCircle className="h-5 w-5 text-primary" />
                              Sync Results
                            </>
                          )}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        {syncResult.error ? (
                          <p className="text-destructive">{syncResult.error}</p>
                        ) : (
                          <div className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <p className="text-sm text-muted-foreground">Total Synced</p>
                                <p className="text-2xl font-bold">{syncResult.totalSynced}</p>
                              </div>
                              <div>
                                <p className="text-sm text-muted-foreground">Errors</p>
                                <p className="text-2xl font-bold">{syncResult.totalErrors}</p>
                              </div>
                            </div>

                            {syncResult.syncResults && (
                              <div className="space-y-2">
                                <p className="font-semibold">By Category:</p>
                                {syncResult.syncResults.map((r: any) => (
                                  <div key={r.type} className="flex justify-between items-center p-2 bg-muted rounded">
                                    <span className="capitalize">{r.type}s</span>
                                    <span className="text-sm">
                                      {r.synced} synced, {r.errors} errors
                                    </span>
                                  </div>
                                ))}
                              </div>
                            )}

                            <p className="text-xs text-muted-foreground">
                              Completed at: {new Date(syncResult.timestamp).toLocaleString()}
                            </p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </Layout>
  );
}
