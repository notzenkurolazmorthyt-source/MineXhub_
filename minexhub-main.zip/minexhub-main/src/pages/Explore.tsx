import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, SlidersHorizontal, X } from "lucide-react";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ModCard } from "@/components/ModCard";
import { useSearchParams } from "react-router-dom";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import type { Database } from "@/integrations/supabase/types";

const ITEMS_PER_PAGE = 12;

const javaContentTypes = [
  { value: "all", label: "All Types", icon: "📦" },
  { value: "mod", label: "Mods", icon: "⚙️" },
  { value: "shader", label: "Shaders", icon: "✨" },
  { value: "resourcepack", label: "Resource Packs", icon: "🎨" },
  { value: "plugin", label: "Plugins", icon: "🔌" },
  { value: "modpack", label: "Modpacks", icon: "📚" },
  { value: "datapack", label: "Data Packs", icon: "📋" },
];

const bedrockContentTypes = [
  { value: "all", label: "All Types", icon: "📦" },
  { value: "mod", label: "Add-ons", icon: "🧩" },
  { value: "resourcepack", label: "Texture Packs", icon: "🎨" },
  { value: "shader", label: "Shaders", icon: "✨" },
  { value: "modpack", label: "Worlds", icon: "🌍" },
  { value: "datapack", label: "Skins", icon: "👤" },
];

const platforms = [
  { value: "all", label: "All Platforms" },
  { value: "modrinth", label: "Modrinth" },
  { value: "curseforge", label: "CurseForge" },
  { value: "9minecraft", label: "9Minecraft" },
];

// Bedrock device platforms
const bedrockDevices = [
  { value: "all", label: "All Devices", icon: "📱" },
  { value: "windows", label: "Windows 10/11", icon: "🖥️" },
  { value: "android", label: "Android", icon: "🤖" },
  { value: "ios", label: "iOS", icon: "🍎" },
  { value: "xbox", label: "Xbox", icon: "🎮" },
  { value: "playstation", label: "PlayStation", icon: "🎮" },
  { value: "switch", label: "Nintendo Switch", icon: "🕹️" },
];

// Bedrock versions
const bedrockVersions = [
  "1.21.50", "1.21.44", "1.21.40", "1.21.30", "1.21.20", "1.21.10", "1.21.0",
  "1.20.80", "1.20.70", "1.20.60", "1.20.50", "1.20.40", "1.20.30", "1.20.10", "1.20.0",
  "1.19.80", "1.19.70", "1.19.60", "1.19.50", "1.19.40", "1.19.30", "1.19.20", "1.19.10", "1.19.0",
  "1.18.30", "1.18.10", "1.18.0",
  "1.17.40", "1.17.30", "1.17.10", "1.17.0",
  "1.16.220", "1.16.200", "1.16.100", "1.16.40", "1.16.20", "1.16.0",
];

// Loader display info with icons
const loaderInfo: Record<string, { label: string; color: string }> = {
  fabric: { label: "Fabric", color: "bg-amber-500/20 text-amber-400 border-amber-500/30" },
  forge: { label: "Forge", color: "bg-orange-500/20 text-orange-400 border-orange-500/30" },
  quilt: { label: "Quilt", color: "bg-purple-500/20 text-purple-400 border-purple-500/30" },
  neoforge: { label: "NeoForge", color: "bg-red-500/20 text-red-400 border-red-500/30" },
  optifine: { label: "OptiFine", color: "bg-red-600/20 text-red-300 border-red-600/30" },
  iris: { label: "Iris", color: "bg-cyan-500/20 text-cyan-400 border-cyan-500/30" },
  vanilla: { label: "Vanilla", color: "bg-green-500/20 text-green-400 border-green-500/30" },
  paper: { label: "Paper", color: "bg-sky-500/20 text-sky-400 border-sky-500/30" },
  spigot: { label: "Spigot", color: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30" },
  velocity: { label: "Velocity", color: "bg-teal-500/20 text-teal-400 border-teal-500/30" },
  bukkit: { label: "Bukkit", color: "bg-blue-500/20 text-blue-400 border-blue-500/30" },
  purpur: { label: "Purpur", color: "bg-violet-500/20 text-violet-400 border-violet-500/30" },
};

export default function Explore() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchQuery, setSearchQuery] = useState("");
  const [showFilters, setShowFilters] = useState(true);
  
  const modType = searchParams.get("type") || "all";
  const edition = searchParams.get("edition") || "all";
  const currentPage = parseInt(searchParams.get("page") || "1");
  const selectedLoaders = searchParams.get("loaders")?.split(",").filter(Boolean) || [];
  const selectedVersions = searchParams.get("versions")?.split(",").filter(Boolean) || [];
  const platform = searchParams.get("platform") || "all";
  const bedrockDevice = searchParams.get("device") || "all";
  const sortBy = searchParams.get("sort") || "downloads";

  // Get page title based on edition
  const pageTitle = edition === "java" ? "Java Edition Content" : 
                    edition === "bedrock" ? "Bedrock Edition Content" : 
                    "Explore Content";

  // Fetch available loaders
  const { data: loaders } = useQuery({
    queryKey: ["loaders"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("version_loaders")
        .select("loader")
        .order("loader");
      if (error) throw error;
      const unique = Array.from(new Set(
        data?.map(l => l.loader).filter((l): l is NonNullable<typeof l> => l != null) || []
      ));
      return unique;
    }
  });

  // Fetch MC versions (oldest to latest, including snapshots)
  const { data: mcVersions } = useQuery({
    queryKey: ["minecraft-versions"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("minecraft_versions")
        .select("version")
        .order("version", { ascending: true });
      if (error) throw error;
      return data?.map(v => v.version) || [];
    }
  });

  // Quick version filters - edition specific
  const javaPopularVersions = ['1.21.4', '1.20.1', '1.19.4', '1.18.2', '1.16.5', '1.12.2'];
  const bedrockPopularVersions = ['1.21.50', '1.21.40', '1.20.80', '1.20.0', '1.19.80', '1.18.30'];
  const popularVersions = edition === "bedrock" ? bedrockPopularVersions : javaPopularVersions;
  const latestRelease = edition === "bedrock" ? '1.21.50' : '1.21.4';
  const latestSnapshot = mcVersions?.find(v => typeof v === 'string' && v.includes('w')) || '24w45a';

  const setQuickVersion = (version: string) => {
    const params = new URLSearchParams(searchParams);
    params.set("versions", version);
    params.set("page", "1");
    setSearchParams(params);
  };

  const { data: modsData, isLoading } = useQuery({
    queryKey: ["mods", modType, edition, currentPage, selectedLoaders, selectedVersions, platform, sortBy, searchQuery],
    queryFn: async () => {
      let query = supabase
        .from("mods")
        .select(`
          *,
          mod_versions (
            version_loaders (loader)
          )
        `, { count: "exact" })
        .eq("status", "approved");

      if (modType !== "all") {
        const validModType = modType as Database['public']['Enums']['mod_type'];
        query = query.eq("mod_type", validModType);
      }

      // Filter by edition
      if (edition !== "all") {
        query = query.eq("edition", edition);
      }

      if (searchQuery) {
        query = query.or(`name.ilike.%${searchQuery}%,description.ilike.%${searchQuery}%`);
      }

      // Filter by loaders
      if (selectedLoaders.length > 0) {
        const { data: versionIds } = await supabase
          .from("version_loaders")
          .select("version_id")
          .in("loader", selectedLoaders as any);
        
        if (versionIds && versionIds.length > 0) {
          const { data: modVersions } = await supabase
            .from("mod_versions")
            .select("mod_id")
            .in("id", versionIds.map(v => v.version_id));
          
          if (modVersions && modVersions.length > 0) {
            const modIds = Array.from(new Set(modVersions.map(mv => mv.mod_id)));
            query = query.in("id", modIds);
          }
        }
      }

      // Filter by MC versions
      if (selectedVersions.length > 0) {
        const { data: mcVersionIds } = await supabase
          .from("minecraft_versions")
          .select("id")
          .in("version", selectedVersions);
        
        if (mcVersionIds && mcVersionIds.length > 0) {
          const { data: versionGameVersions } = await supabase
            .from("version_game_versions")
            .select("version_id")
            .in("minecraft_version_id", mcVersionIds.map(v => v.id));
          
          if (versionGameVersions && versionGameVersions.length > 0) {
            const { data: modVersions } = await supabase
              .from("mod_versions")
              .select("mod_id")
              .in("id", versionGameVersions.map(v => v.version_id));
            
            if (modVersions && modVersions.length > 0) {
              const modIds = Array.from(new Set(modVersions.map(mv => mv.mod_id)));
              query = query.in("id", modIds);
            }
          }
        }
      }

      // Filter by platform
      if (platform !== "all") {
        if (platform === "modrinth") {
          query = query.not("modrinth_id", "is", null);
        } else if (platform === "curseforge") {
          query = query.not("curseforge_id", "is", null);
        }
      }

      const from = (currentPage - 1) * ITEMS_PER_PAGE;
      const to = from + ITEMS_PER_PAGE - 1;

      if (sortBy === "downloads") {
        query = query.order("downloads", { ascending: false });
      } else if (sortBy === "recent") {
        query = query.order("created_at", { ascending: false });
      } else if (sortBy === "updated") {
        query = query.order("updated_at", { ascending: false });
      }

      query = query.range(from, to);

      const { data, error, count } = await query;
      if (error) throw error;
      
      // Extract unique loaders for each mod
      const modsWithLoaders = (data || []).map((mod: any) => {
        const allLoaders = mod.mod_versions?.flatMap((v: any) => 
          v.version_loaders?.map((vl: any) => vl.loader) || []
        ) || [];
        const uniqueLoaders = Array.from(new Set(allLoaders)) as string[];
        return { ...mod, loaders: uniqueLoaders };
      });
      
      return { mods: modsWithLoaders, count: count || 0 };
    },
  });

  const totalPages = Math.ceil((modsData?.count || 0) / ITEMS_PER_PAGE);

  const handleTypeChange = (value: string) => {
    const params = new URLSearchParams(searchParams);
    params.set("type", value);
    params.set("page", "1");
    setSearchParams(params);
  };

  const handleSortChange = (value: string) => {
    const params = new URLSearchParams(searchParams);
    params.set("sort", value);
    params.set("page", "1");
    setSearchParams(params);
  };

  const handlePlatformChange = (value: string) => {
    const params = new URLSearchParams(searchParams);
    params.set("platform", value);
    params.set("page", "1");
    setSearchParams(params);
  };

  const toggleLoader = (loader: string) => {
    const params = new URLSearchParams(searchParams);
    const current = selectedLoaders.includes(loader)
      ? selectedLoaders.filter(l => l !== loader)
      : [...selectedLoaders, loader];
    
    if (current.length > 0) {
      params.set("loaders", current.join(","));
    } else {
      params.delete("loaders");
    }
    params.set("page", "1");
    setSearchParams(params);
  };

  const toggleVersion = (version: string) => {
    const params = new URLSearchParams(searchParams);
    const current = selectedVersions.includes(version)
      ? selectedVersions.filter(v => v !== version)
      : [...selectedVersions, version];
    
    if (current.length > 0) {
      params.set("versions", current.join(","));
    } else {
      params.delete("versions");
    }
    params.set("page", "1");
    setSearchParams(params);
  };

  const clearFilters = () => {
    const params = new URLSearchParams({ sort: sortBy });
    if (edition !== "all") params.set("edition", edition);
    setSearchParams(params);
  };

  const handleDeviceChange = (value: string) => {
    const params = new URLSearchParams(searchParams);
    if (value === "all") {
      params.delete("device");
    } else {
      params.set("device", value);
    }
    params.set("page", "1");
    setSearchParams(params);
  };

  const handlePageChange = (page: number) => {
    const params = new URLSearchParams(searchParams);
    params.set("page", page.toString());
    setSearchParams(params);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const activeFiltersCount = 
    (modType !== "all" ? 1 : 0) +
    selectedLoaders.length +
    selectedVersions.length +
    (platform !== "all" ? 1 : 0) +
    (bedrockDevice !== "all" ? 1 : 0);

  const handleEditionChange = (value: string) => {
    const params = new URLSearchParams(searchParams);
    if (value === "all") {
      params.delete("edition");
    } else {
      params.set("edition", value);
    }
    params.set("page", "1");
    setSearchParams(params);
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Edition Toggle */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex rounded-lg bg-muted p-1 gap-1">
            <Button
              variant={edition === "java" ? "default" : "ghost"}
              size="lg"
              onClick={() => handleEditionChange("java")}
              className={`px-8 py-3 text-base font-semibold transition-all ${
                edition === "java" 
                  ? "bg-amber-600 hover:bg-amber-700 text-white shadow-lg" 
                  : "hover:bg-muted-foreground/10"
              }`}
            >
              ☕ Java Edition
            </Button>
            <Button
              variant={edition === "bedrock" ? "default" : "ghost"}
              size="lg"
              onClick={() => handleEditionChange("bedrock")}
              className={`px-8 py-3 text-base font-semibold transition-all ${
                edition === "bedrock" 
                  ? "bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg" 
                  : "hover:bg-muted-foreground/10"
              }`}
            >
              🪨 Bedrock Edition
            </Button>
          </div>
        </div>

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">{pageTitle}</h1>
          <p className="text-muted-foreground">
            Discover {modsData?.count || 0} mods, shaders, resource packs, plugins, modpacks, and datapacks
            {edition !== "all" && ` for ${edition === "java" ? "Java" : "Bedrock"} Edition`}
          </p>
        </div>

        {/* Search and Controls */}
        <div className="mb-6 space-y-4">
          <div className="flex gap-4 items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search content..."
                className="pl-10 w-full"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <Button
              variant={showFilters ? "default" : "outline"}
              onClick={() => setShowFilters(!showFilters)}
              className="shrink-0"
            >
              <SlidersHorizontal className="h-4 w-4 mr-2" />
              Filters
              {activeFiltersCount > 0 && (
                <Badge variant="secondary" className="ml-2">{activeFiltersCount}</Badge>
              )}
            </Button>

            <Select value={sortBy} onValueChange={handleSortChange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent className="bg-background border z-50">
                <SelectItem value="downloads">Most Downloaded</SelectItem>
                <SelectItem value="recent">Recently Added</SelectItem>
                <SelectItem value="updated">Recently Updated</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Active Filters Display */}
          {activeFiltersCount > 0 && (
            <div className="flex flex-wrap gap-2 items-center">
              <span className="text-sm text-muted-foreground">Active filters:</span>
              {modType !== "all" && (
                <Badge variant="secondary" className="gap-1">
                  Type: {(edition === "bedrock" ? bedrockContentTypes : javaContentTypes).find(t => t.value === modType)?.label}
                  <X className="h-3 w-3 cursor-pointer" onClick={() => handleTypeChange("all")} />
                </Badge>
              )}
              {selectedLoaders.map(loader => (
                <Badge key={loader} variant="secondary" className="gap-1 capitalize">
                  {loader}
                  <X className="h-3 w-3 cursor-pointer" onClick={() => toggleLoader(loader)} />
                </Badge>
              ))}
              {selectedVersions.map(version => (
                <Badge key={version} variant="secondary" className="gap-1">
                  MC {version}
                  <X className="h-3 w-3 cursor-pointer" onClick={() => toggleVersion(version)} />
                </Badge>
              ))}
              {platform !== "all" && (
                <Badge variant="secondary" className="gap-1">
                  {platforms.find(p => p.value === platform)?.label}
                  <X className="h-3 w-3 cursor-pointer" onClick={() => handlePlatformChange("all")} />
                </Badge>
              )}
              {bedrockDevice !== "all" && (
                <Badge variant="secondary" className="gap-1">
                  {bedrockDevices.find(d => d.value === bedrockDevice)?.label}
                  <X className="h-3 w-3 cursor-pointer" onClick={() => handleDeviceChange("all")} />
                </Badge>
              )}
              <Button variant="ghost" size="sm" onClick={clearFilters}>
                Clear all
              </Button>
            </div>
          )}
        </div>

        <div className="flex gap-6">
          {/* Filters Sidebar */}
          {showFilters && (
            <Card className="w-72 p-6 h-fit sticky top-4 shrink-0">
              <ScrollArea className="h-[calc(100vh-12rem)]">
                <div className="space-y-6">
                  {/* Content Type */}

                  {/* Content Type */}
                  <div>
                    <h3 className="font-semibold mb-3">Content Type</h3>
                    <div className="space-y-2">
                      {(edition === "bedrock" ? bedrockContentTypes : javaContentTypes).map((type) => (
                        <button
                          key={type.value}
                          onClick={() => handleTypeChange(type.value)}
                          className={`w-full text-left px-3 py-2 rounded-lg transition-colors flex items-center gap-2 ${
                            modType === type.value
                              ? "bg-primary text-primary-foreground"
                              : "hover:bg-muted"
                          }`}
                        >
                          <span>{type.icon}</span>
                          <span className="text-sm">{type.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  {/* Bedrock Device Platform - Only show for Bedrock */}
                  {edition === "bedrock" && (
                    <>
                      <div>
                        <h3 className="font-semibold mb-3">Device Platform</h3>
                        <div className="space-y-2">
                          {bedrockDevices.map((device) => (
                            <button
                              key={device.value}
                              onClick={() => handleDeviceChange(device.value)}
                              className={`w-full text-left px-3 py-2 rounded-lg transition-colors flex items-center gap-2 ${
                                bedrockDevice === device.value
                                  ? "bg-emerald-600 text-white"
                                  : "hover:bg-muted"
                              }`}
                            >
                              <span>{device.icon}</span>
                              <span className="text-sm">{device.label}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                      <Separator />
                    </>
                  )}

                  {/* Loaders - Only show for Java */}
                  {edition !== "bedrock" && (
                    <>
                      <div>
                        <h3 className="font-semibold mb-3">Loaders / Platforms</h3>
                        <div className="space-y-2">
                          {loaders?.map((loader) => {
                            const info = loaderInfo[loader] || { label: loader, color: "bg-muted" };
                            return (
                              <label
                                key={loader}
                                className="flex items-center gap-2 cursor-pointer hover:bg-muted p-2 rounded"
                              >
                                <input
                                  type="checkbox"
                                  checked={selectedLoaders.includes(loader)}
                                  onChange={() => toggleLoader(loader)}
                                  className="rounded border-input"
                                />
                                <Badge variant="outline" className={`${info.color} capitalize`}>
                                  {info.label}
                                </Badge>
                              </label>
                            );
                          })}
                          {(!loaders || loaders.length === 0) && (
                            <p className="text-sm text-muted-foreground">No loaders available</p>
                          )}
                        </div>
                      </div>
                      <Separator />
                    </>
                  )}

                  {/* Version Section */}
                  <div>
                    <h3 className="font-semibold mb-3">
                      {edition === "bedrock" ? "Bedrock Version" : "Minecraft Version"}
                    </h3>
                    <p className="text-xs text-muted-foreground mb-3">
                      {edition === "bedrock" 
                        ? `${bedrockVersions.length} versions available`
                        : `${mcVersions?.length || 0} versions available`
                      }
                    </p>

                    {/* Quick Filters */}
                    <div className="space-y-2 mb-4">
                      <p className="text-xs font-medium text-muted-foreground uppercase">Quick Select</p>
                      <div className="flex flex-wrap gap-2">
                        <Button
                          size="sm"
                          variant={selectedVersions.includes(latestRelease) ? "default" : "outline"}
                          onClick={() => setQuickVersion(latestRelease)}
                          className="text-xs h-7"
                        >
                          Latest Release
                        </Button>
                        {edition !== "bedrock" && (
                          <Button
                            size="sm"
                            variant={selectedVersions.includes(latestSnapshot) ? "default" : "outline"}
                            onClick={() => setQuickVersion(latestSnapshot)}
                            className="text-xs h-7"
                          >
                            Latest Snapshot
                          </Button>
                        )}
                      </div>
                      
                      <p className="text-xs font-medium text-muted-foreground uppercase mt-3">Popular</p>
                      <div className="flex flex-wrap gap-2">
                        {popularVersions.map(ver => (
                          <Button
                            key={ver}
                            size="sm"
                            variant={selectedVersions.includes(ver) ? "default" : "outline"}
                            onClick={() => setQuickVersion(ver)}
                            className="text-xs h-7 font-mono"
                          >
                            {ver}
                          </Button>
                        ))}
                      </div>
                    </div>

                    <Separator className="my-3" />

                    {/* All Versions List */}
                    <p className="text-xs font-medium text-muted-foreground uppercase mb-2">All Versions</p>
                    <ScrollArea className="h-64">
                      <div className="space-y-1">
                        {(edition === "bedrock" ? bedrockVersions : mcVersions?.slice().reverse() || []).map((version) => (
                          <label
                            key={version}
                            className="flex items-center gap-2 cursor-pointer hover:bg-muted p-2 rounded transition-colors"
                          >
                            <input
                              type="checkbox"
                              checked={selectedVersions.includes(version)}
                              onChange={() => toggleVersion(version)}
                              className="rounded border-input"
                            />
                            <span className="text-sm font-mono flex-1">
                              {version}
                            </span>
                            {version.includes('w') && (
                              <Badge variant="outline" className="text-xs shrink-0">Snapshot</Badge>
                            )}
                            {version.includes('Beta') && (
                              <Badge variant="secondary" className="text-xs shrink-0">Beta</Badge>
                            )}
                          </label>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>

                  <Separator />

                  {/* Platform */}
                  <div>
                    <h3 className="font-semibold mb-3">Platform</h3>
                    <div className="space-y-2">
                      {platforms.map((plat) => (
                        <button
                          key={plat.value}
                          onClick={() => handlePlatformChange(plat.value)}
                          className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                            platform === plat.value
                              ? "bg-primary text-primary-foreground"
                              : "hover:bg-muted"
                          }`}
                        >
                          <span className="text-sm">{plat.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </Card>
          )}

          {/* Content Grid */}
          <div className="flex-1 min-w-0">
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(9)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="bg-muted h-48 rounded-lg mb-4" />
                    <div className="bg-muted h-4 rounded w-3/4 mb-2" />
                    <div className="bg-muted h-4 rounded w-1/2" />
                  </div>
                ))}
              </div>
            ) : modsData?.mods.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground">No content found matching your filters.</p>
                <Button variant="outline" onClick={clearFilters} className="mt-4">
                  Clear Filters
                </Button>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                  {modsData?.mods.map((mod: any) => (
                    <ModCard 
                      key={mod.id}
                      id={mod.id}
                      slug={mod.slug}
                      name={mod.name}
                      summary={mod.summary}
                      iconUrl={mod.icon_url || undefined}
                      downloads={mod.downloads}
                      modType={mod.mod_type}
                      featured={mod.featured}
                      loaders={mod.loaders}
                    />
                  ))}
                </div>

                {totalPages > 1 && (
                  <Pagination>
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious
                          onClick={() => currentPage > 1 && handlePageChange(currentPage - 1)}
                          className={currentPage === 1 ? "pointer-events-none opacity-50" : "cursor-pointer"}
                        />
                      </PaginationItem>
                      
                      {[...Array(Math.min(5, totalPages))].map((_, i) => {
                        let pageNum;
                        if (totalPages <= 5) {
                          pageNum = i + 1;
                        } else if (currentPage <= 3) {
                          pageNum = i + 1;
                        } else if (currentPage >= totalPages - 2) {
                          pageNum = totalPages - 4 + i;
                        } else {
                          pageNum = currentPage - 2 + i;
                        }
                        
                        return (
                          <PaginationItem key={pageNum}>
                            <PaginationLink
                              onClick={() => handlePageChange(pageNum)}
                              isActive={currentPage === pageNum}
                              className="cursor-pointer"
                            >
                              {pageNum}
                            </PaginationLink>
                          </PaginationItem>
                        );
                      })}
                      
                      {totalPages > 5 && currentPage < totalPages - 2 && (
                        <PaginationItem>
                          <PaginationEllipsis />
                        </PaginationItem>
                      )}
                      
                      <PaginationItem>
                        <PaginationNext
                          onClick={() => currentPage < totalPages && handlePageChange(currentPage + 1)}
                          className={currentPage === totalPages ? "pointer-events-none opacity-50" : "cursor-pointer"}
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
