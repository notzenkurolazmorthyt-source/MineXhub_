import { Link } from "react-router-dom";
import Layout from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Puzzle, 
  Palette, 
  Sparkles, 
  User, 
  ArrowRight, 
  Download, 
  Star,
  Smartphone,
  Gamepad2,
  Monitor
} from "lucide-react";

const bedrockCategories = [
  {
    id: "addon",
    title: "Add-ons",
    description: "Behavior packs and resource packs that modify gameplay, add new mobs, items, and mechanics",
    icon: Puzzle,
    color: "from-orange-500 to-amber-600",
    bgColor: "bg-orange-500/10",
    borderColor: "border-orange-500/30",
    count: "2,500+",
    popular: ["Custom Mobs", "New Items", "Game Mechanics", "UI Changes"],
    link: "/explore?edition=bedrock&type=addon"
  },
  {
    id: "texture",
    title: "Texture Packs",
    description: "Transform your world with high-quality textures, from realistic to stylized art styles",
    icon: Palette,
    color: "from-purple-500 to-pink-600",
    bgColor: "bg-purple-500/10",
    borderColor: "border-purple-500/30",
    count: "1,800+",
    popular: ["Realistic", "Cartoon", "Medieval", "Modern"],
    link: "/explore?edition=bedrock&type=resourcepack"
  },
  {
    id: "shader",
    title: "Shaders",
    description: "Enhance your visuals with stunning lighting, shadows, and atmospheric effects",
    icon: Sparkles,
    color: "from-cyan-500 to-blue-600",
    bgColor: "bg-cyan-500/10",
    borderColor: "border-cyan-500/30",
    count: "500+",
    popular: ["RTX", "Realistic", "Performance", "Fantasy"],
    link: "/explore?edition=bedrock&type=shader"
  },
  {
    id: "skin",
    title: "Skins",
    description: "Express yourself with unique character skins, from heroes to custom creations",
    icon: User,
    color: "from-green-500 to-emerald-600",
    bgColor: "bg-green-500/10",
    borderColor: "border-green-500/30",
    count: "10,000+",
    popular: ["Anime", "Superheroes", "Fantasy", "Original"],
    link: "/explore?edition=bedrock&type=skin"
  }
];

const featuredContent = [
  {
    title: "RTX Texture Pack",
    type: "Texture",
    downloads: "125K",
    rating: 4.9,
    image: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400&h=300&fit=crop"
  },
  {
    title: "Enhanced Biomes Addon",
    type: "Addon",
    downloads: "89K",
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400&h=300&fit=crop"
  },
  {
    title: "Cinematic Shaders",
    type: "Shader",
    downloads: "200K",
    rating: 4.9,
    image: "https://images.unsplash.com/photo-1560419015-7c427e8ae5ba?w=400&h=300&fit=crop"
  }
];

export default function Bedrock() {
  return (
    <Layout>
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-br from-green-900/50 via-background to-emerald-900/30">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1920&h=600&fit=crop')] opacity-10 bg-cover bg-center" />
        <div className="container mx-auto px-4 py-16 relative">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 rounded-xl bg-green-500/20 border border-green-500/30">
              <Gamepad2 className="h-8 w-8 text-green-400" />
            </div>
            <Badge variant="outline" className="border-green-500/50 text-green-400">
              Bedrock Edition
            </Badge>
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-green-400 to-emerald-300 bg-clip-text text-transparent">
            Bedrock Content Hub
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mb-8">
            Discover thousands of add-ons, texture packs, shaders, and skins for Minecraft Bedrock Edition. 
            Compatible with mobile, console, and Windows 10/11.
          </p>

          {/* Platform Icons */}
          <div className="flex items-center gap-4 mb-8">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Smartphone className="h-4 w-4" />
              <span>Mobile</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Gamepad2 className="h-4 w-4" />
              <span>Console</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Monitor className="h-4 w-4" />
              <span>Windows</span>
            </div>
          </div>

          <div className="flex flex-wrap gap-4">
            <Button size="lg" className="bg-green-600 hover:bg-green-700">
              <Download className="h-5 w-5 mr-2" />
              Browse All Content
            </Button>
            <Button size="lg" variant="outline" className="border-green-500/50 hover:bg-green-500/10">
              How to Install
            </Button>
          </div>
        </div>
      </div>

      {/* Categories Grid */}
      <div className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold mb-8">Browse by Category</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {bedrockCategories.map((category) => {
            const IconComponent = category.icon;
            return (
              <Link key={category.id} to={category.link}>
                <Card className={`p-6 h-full hover:scale-[1.02] transition-all duration-300 ${category.bgColor} ${category.borderColor} border-2 group cursor-pointer`}>
                  <div className="flex items-start justify-between mb-4">
                    <div className={`p-3 rounded-xl bg-gradient-to-br ${category.color}`}>
                      <IconComponent className="h-6 w-6 text-white" />
                    </div>
                    <Badge variant="secondary">{category.count}</Badge>
                  </div>
                  
                  <h3 className="text-2xl font-bold mb-2">{category.title}</h3>
                  <p className="text-muted-foreground mb-4">{category.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {category.popular.map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex items-center text-primary group-hover:translate-x-2 transition-transform">
                    <span className="font-medium">Explore {category.title}</span>
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </div>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Featured Content */}
      <div className="container mx-auto px-4 py-16 border-t border-border">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold">Featured Bedrock Content</h2>
          <Link to="/explore?edition=bedrock">
            <Button variant="ghost">
              View All <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredContent.map((content, index) => (
            <Card key={index} className="overflow-hidden group cursor-pointer hover:ring-2 hover:ring-primary/50 transition-all">
              <div className="aspect-video relative overflow-hidden">
                <img
                  src={content.image}
                  alt={content.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
                <Badge className="absolute top-3 left-3">{content.type}</Badge>
              </div>
              <div className="p-4">
                <h3 className="font-bold text-lg mb-2">{content.title}</h3>
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Download className="h-4 w-4" />
                    <span>{content.downloads}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                    <span>{content.rating}</span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Installation Guide CTA */}
      <div className="container mx-auto px-4 py-16">
        <Card className="p-8 bg-gradient-to-r from-green-900/30 to-emerald-900/30 border-green-500/30">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="text-2xl font-bold mb-2">New to Bedrock Mods?</h3>
              <p className="text-muted-foreground">
                Learn how to install add-ons, texture packs, and shaders on your device with our step-by-step guides.
              </p>
            </div>
            <Button size="lg" className="bg-green-600 hover:bg-green-700 whitespace-nowrap">
              View Installation Guides
            </Button>
          </div>
        </Card>
      </div>
    </Layout>
  );
}