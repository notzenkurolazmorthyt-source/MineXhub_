import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, SlidersHorizontal, X, ArrowLeft, ArrowRight, Smartphone, Gamepad2, Monitor } from "lucide-react";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ModCard } from "@/components/ModCard";
import { useSearchParams, Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import type { Database } from "@/integrations/supabase/types";

const ITEMS_PER_PAGE = 24;

const bedrockContentTypes = [
  { value: "all", label: "All Types", icon: "📦" },
  { value: "mod", label: "Add-ons", icon: "🧩" },
  { value: "resourcepack", label: "Texture Packs", icon: "🎨" },
  { value: "shader", label: "Shaders", icon: "✨" },
  { value: "modpack", label: "Worlds", icon: "🌍" },
  { value: "datapack", label: "Skins", icon: "👤" },
];

const bedrockDevices = [
  { value: "all", label: "All Devices", icon: <Monitor className="h-4 w-4" /> },
  { value: "windows", label: "Windows 10/11", icon: <Monitor className="h-4 w-4" /> },
  { value: "android", label: "Android", icon: <Smartphone className="h-4 w-4" /> },
  { value: "ios", label: "iOS", icon: <Smartphone className="h-4 w-4" /> },
  { value: "xbox", label: "Xbox", icon: <Gamepad2 className="h-4 w-4" /> },
  { value: "playstation", label: "PlayStation", icon: <Gamepad2 className="h-4 w-4" /> },
  { value: "switch", label: "Nintendo Switch", icon: <Gamepad2 className="h-4 w-4" /> },
];

const bedrockVersions = [
  "1.21.50", "1.21.44", "1.21.40", "1.21.30", "1.21.20", "1.21.10", "1.21.0",
  "1.20.80", "1.20.70", "1.20.60", "1.20.50", "1.20.40", "1.20.30", "1.20.10", "1.20.0",
  "1.19.80", "1.19.70", "1.19.60", "1.19.50", "1.19.40", "1.19.30", "1.19.20", "1.19.10", "1.19.0",
  "1.18.30", "1.18.10", "1.18.0",
  "1.17.40", "1.17.30", "1.17.10", "1.17.0",
  "1.16.220", "1.16.200", "1.16.100", "1.16.40", "1.16.20", "1.16.0",
];

const platforms = [
  { value: "all", label: "All Platforms" },
  { value: "modrinth", label: "Modrinth" },
  { value: "mcpedl", label: "MCPEDL" },
];

export default function BedrockExplore() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchQuery, setSearchQuery] = useState("");
  const [showFilters, setShowFilters] = useState(true);
  
  const modType = searchParams.get("type") || "all";
  const currentPage = parseInt(searchParams.get("page") || "1");
  const selectedVersions = searchParams.get("versions")?.split(",").filter(Boolean) || [];
  const platform = searchParams.get("platform") || "all";
  const bedrockDevice = searchParams.get("device") || "all";
  const sortBy = searchParams.get("sort") || "downloads";

  const popularVersions = ['1.21.50', '1.21.40', '1.20.80', '1.20.0', '1.19.80', '1.18.30'];
  const latestRelease = '1.21.50';

  const setQuickVersion = (version: string) => {
    const params = new URLSearchParams(searchParams);
    params.set("versions", version);
    params.set("page", "1");
    setSearchParams(params);
  };

  const { data: modsData, isLoading } = useQuery({
    queryKey: ["bedrock-mods", modType, currentPage, selectedVersions, platform, bedrockDevice, sortBy, searchQuery],
    queryFn: async () => {
      let query = supabase
        .from("mods")
        .select("*", { count: "exact" })
        .eq("status", "approved")
        .eq("edition", "bedrock");

      if (modType !== "all") {
        const validModType = modType as Database['public']['Enums']['mod_type'];
        query = query.eq("mod_type", validModType);
      }

      if (searchQuery) {
        query = query.or(`name.ilike.%${searchQuery}%,description.ilike.%${searchQuery}%`);
      }

      // Filter by platform
      if (platform !== "all") {
        if (platform === "modrinth") {
          query = query.not("modrinth_id", "is", null);
        }
      }

      const from = (currentPage - 1) * ITEMS_PER_PAGE;
      const to = from + ITEMS_PER_PAGE - 1;

      if (sortBy === "downloads") {
        query = query.order("downloads", { ascending: false });
      } else if (sortBy === "recent") {
        query = query.order("created_at", { ascending: false });
      } else if (sortBy === "updated") {
        query = query.order("updated_at", { ascending: false });
      }

      query = query.range(from, to);

      const { data, error, count } = await query;
      if (error) throw error;
      
      return { mods: data || [], count: count || 0 };
    },
  });

  const totalPages = Math.ceil((modsData?.count || 0) / ITEMS_PER_PAGE);

  const handleTypeChange = (value: string) => {
    const params = new URLSearchParams(searchParams);
    params.set("type", value);
    params.set("page", "1");
    setSearchParams(params);
  };

  const handleSortChange = (value: string) => {
    const params = new URLSearchParams(searchParams);
    params.set("sort", value);
    params.set("page", "1");
    setSearchParams(params);
  };

  const handlePlatformChange = (value: string) => {
    const params = new URLSearchParams(searchParams);
    params.set("platform", value);
    params.set("page", "1");
    setSearchParams(params);
  };

  const handleDeviceChange = (value: string) => {
    const params = new URLSearchParams(searchParams);
    if (value === "all") {
      params.delete("device");
    } else {
      params.set("device", value);
    }
    params.set("page", "1");
    setSearchParams(params);
  };

  const toggleVersion = (version: string) => {
    const params = new URLSearchParams(searchParams);
    const current = selectedVersions.includes(version)
      ? selectedVersions.filter(v => v !== version)
      : [...selectedVersions, version];
    
    if (current.length > 0) {
      params.set("versions", current.join(","));
    } else {
      params.delete("versions");
    }
    params.set("page", "1");
    setSearchParams(params);
  };

  const clearFilters = () => {
    const params = new URLSearchParams({ sort: sortBy });
    setSearchParams(params);
  };

  const handlePageChange = (page: number) => {
    const params = new URLSearchParams(searchParams);
    params.set("page", page.toString());
    setSearchParams(params);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const activeFiltersCount = 
    (modType !== "all" ? 1 : 0) +
    selectedVersions.length +
    (platform !== "all" ? 1 : 0) +
    (bedrockDevice !== "all" ? 1 : 0);

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Back to Home */}
        <Link to="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 transition-colors">
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Home</span>
        </Link>

        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-600/20 flex items-center justify-center">
              <span className="text-2xl">🪨</span>
            </div>
            <div>
              <h1 className="text-4xl font-bold">Bedrock Edition</h1>
              <p className="text-muted-foreground">Mobile / Console / Windows 10+</p>
            </div>
          </div>
          <div className="flex items-center gap-4 mb-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Smartphone className="h-4 w-4" />
              <span>Mobile</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Gamepad2 className="h-4 w-4" />
              <span>Console</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Monitor className="h-4 w-4" />
              <span>Windows</span>
            </div>
          </div>
          <p className="text-muted-foreground">
            Discover {modsData?.count || 0} add-ons, texture packs, shaders, worlds, and skins for Bedrock Edition
          </p>
        </div>

        {/* Search and Controls */}
        <div className="mb-6 space-y-4">
          <div className="flex gap-4 items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search Bedrock content..."
                className="pl-10 w-full"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <Button
              variant={showFilters ? "default" : "outline"}
              onClick={() => setShowFilters(!showFilters)}
              className="shrink-0"
            >
              <SlidersHorizontal className="h-4 w-4 mr-2" />
              Filters
              {activeFiltersCount > 0 && (
                <Badge variant="secondary" className="ml-2">{activeFiltersCount}</Badge>
              )}
            </Button>

            <Select value={sortBy} onValueChange={handleSortChange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent className="bg-background border z-50">
                <SelectItem value="downloads">Most Downloaded</SelectItem>
                <SelectItem value="recent">Recently Added</SelectItem>
                <SelectItem value="updated">Recently Updated</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Active Filters */}
          {activeFiltersCount > 0 && (
            <div className="flex flex-wrap gap-2 items-center">
              <span className="text-sm text-muted-foreground">Active filters:</span>
              {modType !== "all" && (
                <Badge variant="secondary" className="gap-1">
                  Type: {bedrockContentTypes.find(t => t.value === modType)?.label}
                  <X className="h-3 w-3 cursor-pointer" onClick={() => handleTypeChange("all")} />
                </Badge>
              )}
              {selectedVersions.map(version => (
                <Badge key={version} variant="secondary" className="gap-1">
                  v{version}
                  <X className="h-3 w-3 cursor-pointer" onClick={() => toggleVersion(version)} />
                </Badge>
              ))}
              {platform !== "all" && (
                <Badge variant="secondary" className="gap-1">
                  {platforms.find(p => p.value === platform)?.label}
                  <X className="h-3 w-3 cursor-pointer" onClick={() => handlePlatformChange("all")} />
                </Badge>
              )}
              {bedrockDevice !== "all" && (
                <Badge variant="secondary" className="gap-1">
                  {bedrockDevices.find(d => d.value === bedrockDevice)?.label}
                  <X className="h-3 w-3 cursor-pointer" onClick={() => handleDeviceChange("all")} />
                </Badge>
              )}
              <Button variant="ghost" size="sm" onClick={clearFilters}>
                Clear all
              </Button>
            </div>
          )}
        </div>

        <div className="flex gap-6">
          {/* Filters Sidebar */}
          {showFilters && (
            <Card className="w-72 p-6 h-fit sticky top-4 shrink-0">
              <ScrollArea className="h-[calc(100vh-12rem)]">
                <div className="space-y-6">
                  {/* Content Type */}
                  <div>
                    <h3 className="font-semibold mb-3">Content Type</h3>
                    <div className="space-y-2">
                      {bedrockContentTypes.map((type) => (
                        <button
                          key={type.value}
                          onClick={() => handleTypeChange(type.value)}
                          className={`w-full text-left px-3 py-2 rounded-lg transition-colors flex items-center gap-2 ${
                            modType === type.value
                              ? "bg-emerald-600 text-white"
                              : "hover:bg-muted"
                          }`}
                        >
                          <span>{type.icon}</span>
                          <span className="text-sm">{type.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  {/* Device Platform */}
                  <div>
                    <h3 className="font-semibold mb-3">Device Platform</h3>
                    <div className="space-y-2">
                      {bedrockDevices.map((device) => (
                        <button
                          key={device.value}
                          onClick={() => handleDeviceChange(device.value)}
                          className={`w-full text-left px-3 py-2 rounded-lg transition-colors flex items-center gap-2 ${
                            bedrockDevice === device.value
                              ? "bg-emerald-600 text-white"
                              : "hover:bg-muted"
                          }`}
                        >
                          {device.icon}
                          <span className="text-sm">{device.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  {/* Bedrock Version */}
                  <div>
                    <h3 className="font-semibold mb-3">Bedrock Version</h3>
                    <p className="text-xs text-muted-foreground mb-3">
                      {bedrockVersions.length} versions available
                    </p>

                    {/* Quick Filters */}
                    <div className="space-y-2 mb-4">
                      <p className="text-xs font-medium text-muted-foreground uppercase">Quick Select</p>
                      <div className="flex flex-wrap gap-2">
                        <Button
                          size="sm"
                          variant={selectedVersions.includes(latestRelease) ? "default" : "outline"}
                          onClick={() => setQuickVersion(latestRelease)}
                          className="text-xs h-7"
                        >
                          Latest Release
                        </Button>
                      </div>
                      
                      <p className="text-xs font-medium text-muted-foreground uppercase mt-3">Popular</p>
                      <div className="flex flex-wrap gap-2">
                        {popularVersions.map(ver => (
                          <Button
                            key={ver}
                            size="sm"
                            variant={selectedVersions.includes(ver) ? "default" : "outline"}
                            onClick={() => setQuickVersion(ver)}
                            className="text-xs h-7 font-mono"
                          >
                            {ver}
                          </Button>
                        ))}
                      </div>
                    </div>

                    <Separator className="my-3" />

                    <ScrollArea className="h-48">
                      <div className="space-y-1">
                        {bedrockVersions.map((version) => (
                          <label
                            key={version}
                            className="flex items-center gap-2 cursor-pointer hover:bg-muted p-2 rounded transition-colors"
                          >
                            <input
                              type="checkbox"
                              checked={selectedVersions.includes(version)}
                              onChange={() => toggleVersion(version)}
                              className="rounded border-input"
                            />
                            <span className="text-sm font-mono flex-1">{version}</span>
                          </label>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>

                  <Separator />

                  {/* Platform */}
                  <div>
                    <h3 className="font-semibold mb-3">Source Platform</h3>
                    <div className="space-y-2">
                      {platforms.map((plat) => (
                        <button
                          key={plat.value}
                          onClick={() => handlePlatformChange(plat.value)}
                          className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                            platform === plat.value
                              ? "bg-emerald-600 text-white"
                              : "hover:bg-muted"
                          }`}
                        >
                          <span className="text-sm">{plat.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </Card>
          )}

          {/* Content Grid */}
          <div className="flex-1 min-w-0">
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(9)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="bg-muted h-48 rounded-lg mb-4" />
                    <div className="bg-muted h-4 rounded w-3/4 mb-2" />
                    <div className="bg-muted h-4 rounded w-1/2" />
                  </div>
                ))}
              </div>
            ) : modsData?.mods.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground">No content found matching your filters.</p>
                <Button variant="outline" onClick={clearFilters} className="mt-4">
                  Clear Filters
                </Button>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                  {modsData?.mods.map((mod: any) => (
                    <ModCard 
                      key={mod.id}
                      id={mod.id}
                      slug={mod.slug}
                      name={mod.name}
                      summary={mod.summary}
                      iconUrl={mod.icon_url || undefined}
                      downloads={mod.downloads}
                      modType={mod.mod_type}
                      featured={mod.featured}
                    />
                  ))}
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-center gap-4 py-8">
                    <Button
                      variant="outline"
                      onClick={() => handlePageChange(currentPage - 1)}
                      disabled={currentPage === 1}
                      className="gap-2"
                    >
                      <ArrowLeft className="h-4 w-4" />
                      Previous Page
                    </Button>
                    
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">
                        Page {currentPage} of {totalPages}
                      </span>
                    </div>
                    
                    <Button
                      variant="outline"
                      onClick={() => handlePageChange(currentPage + 1)}
                      disabled={currentPage === totalPages}
                      className="gap-2"
                    >
                      Next Page
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                )}

                {currentPage === totalPages && modsData?.mods.length > 0 && (
                  <p className="text-center text-muted-foreground py-4">No more items</p>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
