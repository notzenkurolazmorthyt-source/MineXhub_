import { useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Layout from '@/components/Layout';
import { useAuth } from '@/hooks/useAuth';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Download, Calendar } from 'lucide-react';

export default function History() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  const { data: history, isLoading } = useQuery({
    queryKey: ['download-history', user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from('download_history')
        .select(`
          downloaded_at,
          version_id,
          mod_versions (
            version_number,
            name,
            mods (
              id,
              slug,
              name,
              icon_url,
              mod_type
            )
          )
        `)
        .eq('user_id', user.id)
        .order('downloaded_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      return data || [];
    },
    enabled: !!user
  });

  if (loading || !user) {
    return (
      <Layout>
        <div className="container mx-auto py-8 px-4">
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto py-8 px-4">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Download className="h-8 w-8 text-primary" />
            <h1 className="text-4xl font-bold">Download History</h1>
          </div>
          <p className="text-muted-foreground">
            Your recent downloads ({history?.length || 0} items)
          </p>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-24" />
            ))}
          </div>
        ) : history && history.length > 0 ? (
          <div className="space-y-4">
            {history.map((item: any, index: number) => {
              const mod = item.mod_versions?.mods;
              const version = item.mod_versions;
              
              if (!mod || !version) return null;
              
              return (
                <Link key={`${item.version_id}-${index}`} to={`/mod/${mod.slug}`}>
                  <Card className="p-4 hover:shadow-lg transition-shadow cursor-pointer">
                    <div className="flex items-center gap-4">
                      {mod.icon_url && (
                        <img 
                          src={mod.icon_url} 
                          alt={mod.name}
                          className="w-16 h-16 rounded-lg object-cover"
                        />
                      )}
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-lg">{mod.name}</h3>
                          <Badge variant="secondary">{mod.mod_type}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          Version: {version.version_number} {version.name && `- ${version.name}`}
                        </p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          <span>
                            {new Date(item.downloaded_at).toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  </Card>
                </Link>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-12">
            <Download className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground text-lg">No download history</p>
            <p className="text-sm text-muted-foreground mt-2">
              Downloads will appear here once you start downloading content
            </p>
          </div>
        )}
      </div>
    </Layout>
  );
}
